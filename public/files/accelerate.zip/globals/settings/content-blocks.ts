import { buttons } from "globals/settings/buttons";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";

export const contentBlocks = {
  text: {
    type: "text",
    name: "Text",
    settings: [
      {
        type: "richtext" as const,
        id: "title",
        label: "Content",
      },
      typeRange({ id: "title_type", label: "Type" }),
      {
        type: "header" as const,
        content: "Layout",
      },
      {
        type: "range" as const,
        id: "margin_bottom",
        label: "Margin Bottom",
        default: 0,
        min: -6,
        max: 42,
        step: 2,
        unit: "px",
      },
      sectionGlobals.responsiveVisibility,
    ],
  },
  image: {
    type: "image",
    name: "Inline Image",
    settings: [
      {
        type: "image_picker" as const,
        id: "image",
        label: "Image",
      },
      {
        type: "range" as const,
        id: "height",
        label: "Height",
        default: 80,
        min: 20,
        max: 200,
        step: 5,
        unit: "px",
      },
      {
        type: "header" as const,
        content: "Layout",
      },
      {
        type: "range" as const,
        id: "margin_bottom",
        label: "Margin Bottom",
        default: 0,
        min: -6,
        max: 42,
        step: 2,
        unit: "px",
      },
      sectionGlobals.responsiveVisibility,
    ],
  },
  accentLine: {
    type: "accent_line",
    name: "Accent line",
    settings: [
      {
        type: "color" as const,
        id: "color",
        label: "Color",
      },
      {
        type: "range" as const,
        id: "height",
        label: "height",
        default: 2,
        min: 1,
        max: 8,
        step: 1,
        unit: "px",
      },
      {
        type: "range" as const,
        id: "width",
        label: "Width",
        default: 30,
        min: 5,
        max: 280,
        step: 5,
        unit: "px",
      },
      {
        type: "header" as const,
        content: "Layout",
      },
      {
        type: "range" as const,
        id: "margin_bottom",
        label: "Margin Bottom",
        default: 0,
        min: -6,
        max: 42,
        step: 2,
        unit: "px",
      },
      sectionGlobals.responsiveVisibility,
    ],
  },
  buttonGroup: {
    type: "buttons",
    name: "Buttons",
    settings: [
      ...buttons.primary,
      ...buttons.secondary,
      {
        type: "header" as const,
        content: "Layout",
      },
      {
        type: "range" as const,
        id: "margin_bottom",
        label: "Margin Bottom",
        default: 0,
        min: -6,
        max: 42,
        step: 2,
        unit: "px",
      },
      sectionGlobals.responsiveVisibility,
    ],
  },
};
