export function typeRange({
  id,
  label,
  default_font = 2,
}: {
  default_font?: number;
  id: string;
  label: string;
}) {
  return {
    type: "range" as const,
    id: id,
    label: label,
    default: default_font,
    min: 1,
    max: 7,
    step: 1,
    info: "h1-h6, Set to 7 for body text",
  };
}
