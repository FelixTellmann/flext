import { buttonSettings } from "globals/settings/buttons";
import { colSpacing } from "globals/settings/col-spacing";
import { iconListGroups } from "globals/settings/icon-list-groups";
import { rowSpacing } from "globals/settings/row-spacing";

export const productBlocks = {
  app: {
    type: "@app" as const,
  },
  text: {
    type: "text" as const,
    name: "Text",
    settings: [
      {
        type: "richtext" as const,
        id: "text",
        label: "Text block",
      },
    ],
  },
  image: {
    type: "image" as const,
    name: "Image",
    limit: 1,
    settings: [
      {
        id: "image__ratio",
        type: "select" as const,
        default: "pb-[125%]",
        options: [
          {
            value: "pb-[125%]",
            label: "Portrait",
          },
          {
            value: "pb-[100%]",
            label: "Square",
          },
        ],
        label: "Image ratio",
      },
      {
        type: "color_background" as const,
        id: "image__background",
        label: "Image background",
        default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
      },
      {
        type: "checkbox" as const,
        id: "image__drop_shadow",
        label: "Add a drop shadow to the image",
        info: "Transparent images only",
        default: false,
      },
      colSpacing,
      rowSpacing,
    ],
  },
  title: {
    type: "title" as const,
    name: "Title",
    limit: 1,
    settings: [
      {
        type: "range" as const,
        id: "font_scale",
        min: 30,
        max: 250,
        step: 5,
        unit: "%",
        label: "Font size scale",
        default: 100,
      },
      colSpacing,
    ],
  },
  vendor: {
    type: "vendor" as const,
    name: "Vendor",
    limit: 1,
    settings: [colSpacing],
  },
  price: {
    type: "price" as const,
    name: "Price",
    limit: 1,
    settings: [colSpacing],
  },
  variant_selector: {
    type: "variant_selector" as const,
    name: "Variant Selector",
    limit: 1,
    settings: [
      {
        type: "checkbox" as const,
        id: "disable_unavailable",
        label: "Disable Unavailable Variants",
      },
      {
        type: "checkbox" as const,
        id: "image_selector",
        label: "Select variant by image",
        default: false,
        info: "Applies to products with up to 12 Variants and needs an image attached to each variant.",
      },
      {
        type: "header" as const,
        content: "Default Selector options",
      },
      {
        type: "paragraph" as const,
        content:
          "The options apply if the `Variant by Image` selector is disabled or products do not meet the requirements.",
      },
      {
        type: "checkbox" as const,
        id: "color_selector",
        label: "Use Color Selector",
      },
      {
        type: "textarea" as const,
        id: "color_list",
        label: "Color Options",
        default: "color,colour,couleur,cor,colore,farbe,색,色,カラー,färg,farve,szín,barva",
        info: "Comma seperated list of colors to match by Product Option",
      },
      {
        type: "radio" as const,
        id: "default_type",
        options: [
          {
            value: "radio",
            label: "Pills",
          },
          {
            value: "select",
            label: "Dropdown",
          },
        ],
        default: "radio",
        label: "Default Type",
      },
    ],
  },
  product_sibling: {
    type: "product_sibling" as const,
    name: "Product Sibling",
    limit: 1,
    settings: [
      {
        type: "radio" as const,
        id: "selector",
        options: [
          {
            value: "image",
            label: "Image Selector",
          },
          {
            value: "color",
            label: "Color Selector",
          },
          {
            value: "radio",
            label: "Pills",
          },
          {
            value: "select",
            label: "Dropdown",
          },
        ],
        default: "image",
        label: "Default Type",
      },
    ],
  },
  sku: {
    type: "sku" as const,
    name: "SKU",
    limit: 1,
    settings: [colSpacing],
  },
  quantity_selector: {
    type: "quantity_selector" as const,
    name: "Quantity selector",
    limit: 1,
    settings: [colSpacing],
  },
  buy_buttons: {
    type: "buy_buttons" as const,
    name: "Buy buttons",
    limit: 1,
    settings: [colSpacing, buttonSettings.style],
  },
  dynamic_buy_buttons: {
    type: "dynamic_buy_buttons" as const,
    name: "Dynamic Buy buttons",
    limit: 1,
    settings: [
      {
        type: "paragraph" as const,
        content:
          "Using the payment methods available on your store, customers see their preferred option, like PayPal or Apple Pay. [Learn more](https://help.shopify.com/manual/using-themes/change-the-layout/dynamic-checkout)",
      },
      colSpacing,
      buttonSettings.style,
    ],
  },
  description: {
    type: "description" as const,
    name: "Description",
    limit: 1,
    settings: [
      {
        type: "checkbox" as const,
        id: "accordion_style",
        label: "Change H1 Headings to Dropdowns",
      },
    ],
  },
  share: {
    type: "share" as const,
    name: "Share",
    limit: 1,
    settings: [
      {
        type: "paragraph" as const,
        content:
          "If you include a link in social media posts, the page’s featured image will be shown as the preview image. [Learn more](https://help.shopify.com/manual/online-store/images/showing-social-media-thumbnail-images).",
      },
      {
        type: "paragraph" as const,
        content:
          "A store title and description are included with the preview image. [Learn more](https://help.shopify.com/manual/promoting-marketing/seo/adding-keywords#set-a-title-and-description-for-your-online-store).",
      },
      colSpacing,
    ],
  },
  custom_liquid: {
    type: "custom_liquid" as const,
    name: "Custom liquid",
    settings: [
      {
        type: "liquid" as const,
        id: "custom_liquid",
        label: "Custom liquid",
        info: "Add app snippets or other Liquid code to create advanced customizations.",
      },
    ],
  },
  collapsible_tab: {
    type: "collapsible_tab" as const,
    name: "Collapsible row",
    settings: [
      {
        type: "text" as const,
        id: "heading",
        default: "Collapsible row",
        info: "Include a heading that explains the content.",
        label: "Heading",
      },
      {
        type: "select" as const,
        id: "icon",
        options: [
          {
            value: "none",
            label: "None",
          },
          {
            value: "apple",
            label: "Apple",
          },
          {
            value: "banana",
            label: "Banana",
          },
          {
            value: "bottle",
            label: "Bottle",
          },
          {
            value: "box",
            label: "Box",
          },
          {
            value: "carrot",
            label: "Carrot",
          },
          {
            value: "chat_bubble",
            label: "Chat bubble",
          },
          {
            value: "check_mark",
            label: "Check mark",
          },
          {
            value: "clipboard",
            label: "Clipboard",
          },
          {
            value: "dairy",
            label: "Dairy",
          },
          {
            value: "dairy_free",
            label: "Dairy free",
          },
          {
            value: "dryer",
            label: "Dryer",
          },
          {
            value: "eye",
            label: "Eye",
          },
          {
            value: "fire",
            label: "Fire",
          },
          {
            value: "gluten_free",
            label: "Gluten free",
          },
          {
            value: "heart",
            label: "Heart",
          },
          {
            value: "iron",
            label: "Iron",
          },
          {
            value: "leaf",
            label: "Leaf",
          },
          {
            value: "leather",
            label: "Leather",
          },
          {
            value: "lightning_bolt",
            label: "Lightning bolt",
          },
          {
            value: "lipstick",
            label: "Lipstick",
          },
          {
            value: "lock",
            label: "Lock",
          },
          {
            value: "map_pin",
            label: "Map pin",
          },
          {
            value: "nut_free",
            label: "Nut free",
          },
          {
            value: "pants",
            label: "Pants",
          },
          {
            value: "paw_print",
            label: "Paw print",
          },
          {
            value: "pepper",
            label: "Pepper",
          },
          {
            value: "perfume",
            label: "Perfume",
          },
          {
            value: "plane",
            label: "Plane",
          },
          {
            value: "plant",
            label: "Plant",
          },
          {
            value: "price_tag",
            label: "Price tag",
          },
          {
            value: "question_mark",
            label: "Question mark",
          },
          {
            value: "recycle",
            label: "Recycle",
          },
          {
            value: "return",
            label: "Return",
          },
          {
            value: "ruler",
            label: "Ruler",
          },
          {
            value: "serving_dish",
            label: "Serving dish",
          },
          {
            value: "shirt",
            label: "Shirt",
          },
          {
            value: "shoe",
            label: "Shoe",
          },
          {
            value: "silhouette",
            label: "Silhouette",
          },
          {
            value: "snowflake",
            label: "Snowflake",
          },
          {
            value: "star",
            label: "Star",
          },
          {
            value: "stopwatch",
            label: "Stopwatch",
          },
          {
            value: "truck",
            label: "Truck",
          },
          {
            value: "washing",
            label: "Washing",
          },
        ],
        default: "check_mark",
        label: "Icon",
      },
      {
        type: "richtext" as const,
        id: "content",
        label: "Row content",
      },
      {
        type: "page" as const,
        id: "page",
        label: "Row content from page",
      },
    ],
  },
  rating: {
    type: "rating" as const,
    name: "Product rating",
    limit: 1,
    settings: [
      {
        type: "paragraph" as const,
        content:
          "To display a rating, add a product rating app. [Learn more](https://help.shopify.com/manual/online-store/themes/theme-structure/page-types#product-rating-block)",
      },
      colSpacing,
    ],
  },
  complementary: {
    type: "complementary" as const,
    name: "Complementary products",
    limit: 1,
    settings: [
      {
        type: "text" as const,
        id: "title",
        label: "Title",
      },
      {
        type: "checkbox" as const,
        id: "image__show_secondary",
        label: "Show Secondary Image",
      },
      {
        type: "product_list" as const,
        id: "products",
        label: "Default Products",
        info: "Fallback in case complimentary products are not set up.",
        limit: 10,
      },
      {
        type: "paragraph" as const,
        content:
          "To select complementary products, add the Search & Discovery app. [Learn more](https://help.shopify.com/manual/online-store/search-and-discovery/product-recommendations)",
      },
    ],
  },
  icon_with_text: {
    type: "icon_with_text" as const,
    name: "Icon with text",
    settings: [
      {
        type: "select" as const,
        id: "layout",
        options: [
          {
            value: "flex-row",
            label: "Horizontal",
          },
          {
            value: "flex-col",
            label: "Vertical",
          },
        ],
        default: "flex-row",
        label: "Layout",
      },
      {
        type: "range" as const,
        id: "size",
        label: "Size",
        default: 20,
        min: 16,
        max: 36,
        step: 1,
        unit: "px",
      },
      {
        type: "header" as const,
        content: "Content",
        info: "Choose an icon or add an image for each column or row.",
      },
      ...iconListGroups(1),
      ...iconListGroups(2),
      ...iconListGroups(3),
    ],
  },
  inventory: {
    type: "inventory",
    name: "Inventory Count",
    limit: 2,
    settings: [
      {
        type: "range" as const,
        id: "threshold",
        label: "Low inventory threshold",
        min: 2,
        max: 100,
        step: 1,
        default: 5,
      },
    ],
  },
  pre_order: {
    type: "pre_order",
    name: "Pre-order Notice",
    limit: 1,
    settings: [
      {
        type: "radio" as const,
        id: "preorder_date",
        label: "Preorder Notice Detail",
        default: "estimate",
        options: [
          {
            value: "estimate",
            label: "Estimate",
          },
          {
            value: "precise",
            label: "Precise",
          },
          {
            value: "none",
            label: "None",
          },
        ],
      },
    ],
  },
};
