// @ts-ignore
import clsx from "clsx";
import { settingsSchema } from "globals/settings_schema";
import { CloseIcon } from "globals/utils/icons";
import { useWindowSize } from "globals/utils/scrollbar";
import { render } from "preact";
import { FC, PropsWithChildren, useCallback, useEffect, useRef, useState } from "react";

render(<Editor />, document.querySelector("[data-editor-root]"));

function getSettingsCategory() {
  return decodeURIComponent(window.top.location.search)
    .replace(/.*?OnlineStoreThemeSettingsCategory\/([^?]*)\?.*/gi, "$1")
    .replace(/\+/gi, " ");
}

function Editor() {
  const [themeSetting, setThemeSetting] = useState<string>(getSettingsCategory());
  const lastSetting = useRef("");
  const locationCheck = useRef<NodeJS.Timer>(null);
  const { width } = useWindowSize();

  const handleClose = useCallback((e) => {
    setThemeSetting("");
  }, []);

  useEffect(() => {
    locationCheck.current = setInterval(
      () => {
        const isThemeSettings = window.top.location.search.includes(
          "OnlineStoreThemeSettingsCategory"
        );
        const newThemeSettings = getSettingsCategory();

        if (isThemeSettings && lastSetting.current !== newThemeSettings) {
          lastSetting.current = getSettingsCategory();
          setThemeSetting(lastSetting.current);
        }

        if (!isThemeSettings && lastSetting.current !== "") {
          lastSetting.current = "";
          setThemeSetting("");
        }
      },
      250
    );
    return () => {
      clearInterval(locationCheck.current);
    };
  }, []);

  useEffect(() => {
    console.log({ themeSetting });
  }, [themeSetting]);

  if (width < 1000) {
    return null;
  }

  return (
    <>
      {
        {
          /*"Color Group 1": (
            <div className="fixed z-[99999] inset-0 bg-gray-900/20 backdrop-blur flex items-center justify-center">
              <div className="bg-theme-bg text-theme-text color-group-1 h-[calc(100%-4rem)] w-[calc(100%-4rem)] rounded-theme-lg shadow-lg p-6">
                asd
              </div>
            </div>
          ),
          "Color Group 2": (
            <div className="fixed z-[99999] inset-0 bg-gray-900/20 backdrop-blur flex items-center justify-center">
              <div className="bg-theme-bg text-theme-text color-group-2 h-[calc(100%-4rem)] w-[calc(100%-4rem)] rounded-theme-lg shadow-lg p-6">
                asd
              </div>
            </div>
          ),
          "Color Group 3": (
            <div className="fixed z-[99999] inset-0 bg-gray-900/20 backdrop-blur flex items-center justify-center">
              <div className="bg-theme-bg text-theme-text color-group-3 h-[calc(100%-4rem)] w-[calc(100%-4rem)] rounded-theme-lg shadow-lg p-6">
                asd
              </div>
            </div>
          ),*/
          Typography: (
            <SettingsModal handleClose={handleClose}>
              <header className="relative mx-auto grid max-w-[1100px] gap-8 px-8">
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="mb-2 font-sans text-2xl font-bold tracking-tight text-gray-900">
                    Desktop
                  </h2>
                  <h2 className="mb-2 font-sans text-2xl font-bold tracking-tight text-gray-900">
                    Mobile
                  </h2>
                </section>
              </header>
              <main className="scrollbar-y-slim relative mx-auto grid h-[calc(100%-36px)] max-w-[1100px] gap-8 overflow-y-auto px-8 pb-32">
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Body
                  </h2>
                  <p className="p">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque cupiditate
                    dignissimos dolore et harum iste itaque, iure magni non numquam optio, porro qui
                    quidem ratione repellendus sapiente sequi tempore totam. Doloremque officiis
                    perferendis praesentium quod totam! Asperiores, nesciunt, sit! Ab, architecto
                    atque corporis deleniti distinctio dolores excepturi unde.
                  </p>
                  <p className="p text-sm-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque cupiditate
                    dignissimos dolore et harum iste itaque, iure magni non numquam optio, porro qui
                    quidem ratione repellendus sapiente sequi tempore totam.
                  </p>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 1
                  </h2>
                  <h1 className="h1">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit." />
                  </h1>
                  <h1 className="h1 text-sm-h1">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit." />
                  </h1>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 2
                  </h2>
                  <h2 className="h2">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit." />
                  </h2>
                  <h2 className="h2 text-sm-h2">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit." />
                  </h2>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 3
                  </h2>
                  <h3 className="h3">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus." />
                  </h3>
                  <h3 className="h3 text-sm-h3">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus." />
                  </h3>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 4
                  </h2>
                  <h4 className="h4">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h4>
                  <h4 className="h4 text-sm-h4">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h4>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 5
                  </h2>
                  <h5 className="h5">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h5>
                  <h5 className="h5 text-sm-h5">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h5>
                </section>
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Heading 6
                  </h2>
                  <h6 className="h6">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h6>
                  <h6 className="h6 text-sm-h6">
                    <ContentEditable content="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti distinctio dolorem expedita ipsam minus, neque nihil nulla quis ratione reiciendis! Facilis, minima." />
                  </h6>
                </section>
              </main>
            </SettingsModal>
          ),
          Buttons: (
            <SettingsModal handleClose={handleClose}>
              <header className="relative mx-auto grid max-w-[1100px] gap-8 px-8">
                <section className="grid grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="mb-2 font-sans text-2xl font-bold tracking-tight text-gray-900">
                    Desktop
                  </h2>
                  <h2 className="mb-2 font-sans text-2xl font-bold tracking-tight text-gray-900">
                    Mobile
                  </h2>
                </section>
              </header>
              <main className="scrollbar-y-slim relative mx-auto mb-auto grid h-[calc(100%-36px)] max-h-min max-w-[1100px] auto-rows-min gap-8 overflow-y-auto px-8 pb-32">
                <section className="grid h-min grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Primary Button
                  </h2>
                  <div>
                    <button type="button" className="button">
                      <ContentEditable content="Desktop Button" />
                    </button>
                  </div>
                  <div>
                    <button type="button" className="button text-sm-button">
                      <ContentEditable content="Mobile Button" />
                    </button>
                  </div>
                </section>
                <section className="grid h-min grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Primary Button Outline
                  </h2>
                  <div>
                    <button type="button" className="button--outline">
                      <ContentEditable content="Desktop Button" />
                    </button>
                  </div>
                  <div>
                    <button type="button" className="button--outline text-sm-button">
                      <ContentEditable content="Mobile Button" />
                    </button>
                  </div>
                </section>
                <section className="grid h-min grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Secondary Button
                  </h2>
                  <div>
                    <button type="button" className="button-secondary">
                      <ContentEditable content="Desktop Button" />
                    </button>
                  </div>
                  <div>
                    <button type="button" className="button-secondary text-sm-button">
                      <ContentEditable content="Mobile Button" />
                    </button>
                  </div>
                </section>
                <section className="grid h-min grid-cols-[1fr_350px] gap-x-10">
                  <h2 className="col-span-2 mb-2 font-sans text-xl font-semibold tracking-tight text-gray-500">
                    Secondary Button Outline
                  </h2>
                  <div>
                    <button type="button" className="button-secondary--outline">
                      <ContentEditable content="Desktop Button" />
                    </button>
                  </div>
                  <div>
                    <button type="button" className="button-secondary--outline text-sm-button">
                      <ContentEditable content="Mobile Button" />
                    </button>
                  </div>
                </section>
              </main>
            </SettingsModal>
          ),
          "": null,
        }[themeSetting]
      }
    </>
  );
}

function SettingsModal({ children, handleClose }) {
  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-gray-900/20 backdrop-blur">
      <div className="color-group-1 relative h-[calc(100%-4rem)] w-[calc(100%-4rem)] rounded-theme-lg border border-gray-200 bg-gradient-to-br from-gray-100 to-gray-200 px-6 py-12 text-theme-text shadow-lg shadow-lg ">
        <button
          type="button"
          className="absolute top-3 right-3 flex items-center justify-center p-2"
          onClick={handleClose}
        >
          <CloseIcon className="h-4 w-4" />
        </button>
        {children}
      </div>
    </div>
  );
}

function ContentEditable({ content, className = "" }) {
  return (
    <span
      className={clsx("cursor-text outline-none focus:outline-none", className)}
      contentEditable={true}
      spellCheck={false}
      autoCorrect="off"
      autoCapitalize="off"
    >
      {content}
    </span>
  );
}
