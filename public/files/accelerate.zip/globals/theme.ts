import "globals/utils/global-stores";
import { initProductCards } from "globals/snippets/product-card";
import { initCollapsible } from "globals/utils/accordion";
import { initAccountOrders } from "globals/utils/account-orders";
import { initAnimationSlide } from "globals/utils/animation-slide";
import { initCollection } from "globals/utils/collection";
import { initColorSwatches } from "globals/utils/color-swatches";
import { initForms } from "globals/utils/forms";

import "sections/product-drawer/product-drawer";
import { initHeaderMenu } from "globals/utils/header";
import { initPasswordInput } from "globals/utils/password-input";
import { initScrollSlider } from "globals/utils/scroll-slider";
import { initSearch } from "globals/utils/search";
import { initSlideInDrawers } from "globals/utils/slide-in-drawers";
import { initSlideshow } from "globals/utils/slideshow";
import { initTabs } from "globals/utils/tabs";
import { initTooltip } from "globals/utils/tooltip";
import { trapFocus } from "globals/utils/utils";
import { initCart } from "sections/cart-drawer/cart-drawer";

import { initProducts } from "sections/product/product";

const initNoJs = () => {
  document
    .querySelectorAll(".no-js-hidden")
    .forEach((element) => element.classList.remove("no-js-hidden"));
};

const initTheme = () => {
  initNoJs();
  initProductCards();
  initColorSwatches();
  trapFocus(document.body);
  initSlideInDrawers();
  initCollection();
  initTooltip();
  initScrollSlider();
  initHeaderMenu();
  initCart();
  initProducts();
  initSearch();
  initAnimationSlide();
  initSlideshow();
  initCollapsible();
  initTabs();
  initPasswordInput();
  initForms();
  initAccountOrders();
};

initTheme();

const shopifyEvents = [
  "shopify:inspector:activate",
  "shopify:inspector:deactivate",
  "shopify:section:load",
  "shopify:section:unload",
  "shopify:section:select",
  "shopify:section:deselect",
  "shopify:section:reorder",
  "shopify:section:reorder",
  "shopify:block:select",
  "shopify:block:deselect",
];

type ShopifyThemeEditorEvent = Event & {
  detail: any;
};

shopifyEvents.forEach((eventName) => {
  document.addEventListener(eventName, (e: ShopifyThemeEditorEvent) => {
    console.log(e.type);
    console.log(e.detail);
    // console.log(e.target);
    initTheme();
    initNoJs();
  });
});

document.addEventListener("shopify:section:load", (e) => {
  const element = e.target as HTMLElement;
  const { type, disabled } = JSON.parse(element.dataset.shopifyEditorSection);

  initTheme();
});

export const isExternalUrl = (url: string): boolean => {
  const host = window?.location?.hostname;

  const linkHost = (function (url) {
    if (/^https?:?\/\//.test(url)) {
      const anchorElement = document.createElement("a");
      anchorElement.href = url;
      return anchorElement.hostname;
    } else {
      return window?.location?.hostname;
    }
  })(url);

  return host !== linkHost;
};

export const isNotSamePageUrl = (url: string): boolean => {
  if (isExternalUrl(url)) {
    return true;
  }

  const path = window.location.pathname;

  const linkPath = (function (url) {
    if (/^https?:?\/\//.test(url)) {
      const anchorElement = document.createElement("a");
      anchorElement.href = url;
      return anchorElement.pathname;
    } else {
      const anchorElement = document.createElement("a");
      anchorElement.href = window.location.origin + url;
      return anchorElement.pathname;
    }
  })(url);

  return path !== linkPath;
};

export default initTheme;
