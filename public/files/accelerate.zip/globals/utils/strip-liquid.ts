export const stripLiquid = (htmlString: string) => {
  return htmlString
    .replace(/{%[\s-]*capture[^%]*%}(.|\n)*?(?=endcapture)endcapture[^%]*%}/gim, "")
    .replace(/{%[\s-]*comment[^%]*%}(.|\n)*?(?=endcomment)endcomment[^%]*%}/gim, "")
    .replace(/{{(?<=\{\{)(.|\n)*?(?=}})}}/gim, "")
    .replace(/{%(?<=\{%)(.|\n)*?(?=%})%}/gim, "");
};
