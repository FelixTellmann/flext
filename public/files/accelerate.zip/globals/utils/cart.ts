import { _Cart_fetch_api, _Cart_fetch_api_add_input, _Cart_fetch_api_add_return, _Cart_fetch_api_update_input, CartItem } from "globals/utils/types";

export const cart = {
  open: async (): Promise<_Cart_fetch_api> => {
    const data = await (await fetch("/cart.js")).json();
    const cartEvent = new CustomEvent("cart:update", { detail: data });
    document.dispatchEvent(cartEvent);
    const cartOpenEvent = new CustomEvent("cart:open");
    document.dispatchEvent(cartOpenEvent);
    return data;
  },
  get: async (): Promise<_Cart_fetch_api> => {
    const data = (await (await fetch("/cart.js")).json()) as _Cart_fetch_api;
    const cartEvent = new CustomEvent("cart:update", { detail: data });
    document.dispatchEvent(cartEvent);
    return data;
  },
  add: async (cartItems: _Cart_fetch_api_add_input, open = false): Promise<_Cart_fetch_api> => {
    const data = await (
      await fetch("/cart/add.js", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cartItems),
      })
    ).json();
    const cartEvent = new CustomEvent("cart:add", { detail: data });
    document.dispatchEvent(cartEvent);

    if (open) {
      await cart.open();
      return data;
    }
    cart.get();
    return data;
  },
  update: async (updates: _Cart_fetch_api_update_input): Promise<_Cart_fetch_api> => {
    const data = await (
      await fetch("/cart/update.js", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updates),
      })
    ).json();
    cart.get();
    return data;
  },
  change: async (cartItem: CartItem): Promise<_Cart_fetch_api> => {
    const data = await (
      await fetch("/cart/change.js", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cartItem),
      })
    ).json();
    cart.get();
    return data;
  },
  clear: async (): Promise<_Cart_fetch_api> => {
    const data = await (
      await fetch("/cart/clear.js", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
    ).json();
    cart.get();
    return data;
  },
};
window["cart"] = cart;
