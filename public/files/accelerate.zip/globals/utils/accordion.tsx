import clsx from "clsx";
import { PlusIcon } from "globals/utils/icons";
import { render } from "preact";
import { FC, useCallback, useEffect, useRef, useState } from "react";

export const Accordion: FC<{ title: string; content: string; blockId?: string }> = ({
  title,
  content,
  blockId,
}) => {
  const [open, setOpen] = useState(false);
  const [maxHeight, setMaxHeight] = useState(0);
  const heightElementRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>(null);

  const handleClick = useCallback((e) => {
    e.preventDefault();
    setMaxHeight(open ? 0 : heightElementRef.current.scrollHeight);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    if (!open) {
      setOpen(true);
    }
    if (open) {
      timeoutRef.current = setTimeout(
        () => {
          setOpen(false);
        },
        155
      );
    }
  }, [open]);

  const handleShopifyBlockSelect = useCallback((e) => {
    if (e?.detail?.blockId === blockId) {
      setMaxHeight(heightElementRef.current.scrollHeight);
      setOpen(true);
    }
  }, [blockId]);

  const handleShopifyBlockDeselect = useCallback((e) => {
    if (e?.detail?.blockId === blockId) {
      setMaxHeight(0);
      timeoutRef.current = setTimeout(
        () => {
          setOpen(false);
        },
        155
      );
    }
  }, [blockId]);

  useEffect(() => {
    if (blockId) {
      document.addEventListener("shopify:block:select", handleShopifyBlockSelect);
      document.addEventListener("shopify:block:deselect", handleShopifyBlockDeselect);
      return () => {
        document.removeEventListener("shopify:block:select", handleShopifyBlockSelect);
        document.removeEventListener("shopify:block:deselect", handleShopifyBlockDeselect);
      };
    }
    return () => {};
  }, [blockId, handleShopifyBlockDeselect, handleShopifyBlockSelect]);

  return (
    <details className="group flex appearance-none" open={open}>
      <summary className="cursor-pointer select-none py-2" onClick={handleClick}>
        <span className="flex items-center justify-between">
          <h2 className="text-sm font-semibold" dangerouslySetInnerHTML={{ __html: title }} />
          <PlusIcon className={clsx(`h-3 w-3 transition-all`, maxHeight && "-rotate-90")} />
        </span>
      </summary>

      <div
        className="overflow-hidden transition-all duration-150 ease-linear"
        style={{ maxHeight: `${maxHeight}px` }}
        ref={heightElementRef}
      >
        <div
          className="prose prose-sm prose-theme max-w-none pb-2 [&_>_*]:max-w-none"
          dangerouslySetInnerHTML={{ __html: content }}
        ></div>
      </div>
    </details>
  );
};

export const initCollapsible = () => {
  document.querySelectorAll<HTMLDetailsElement>("[data-collapsible]").forEach((item) => {
    const blockId = item.dataset.blockId;
    const title = item.querySelector<HTMLElement>("[data-collapsible-title]").innerHTML;
    const content = item.querySelector<HTMLElement>("[data-collapsible-content]").innerHTML;

    render(<Accordion title={title} content={content} blockId={blockId} />, item.parentElement);
  });

  const MutationObserver = window.MutationObserver || window["WebKitMutationObserver"];

  // define a new observer
  const mutationObserver = new MutationObserver((e) => {
    e?.forEach((record) =>
      record.addedNodes.forEach(async (node) => {
        if (node?.dataset?.collapsible) {
          const item = node as HTMLDivElement;
          const title = item.querySelector<HTMLElement>("[data-collapsible-title]").innerHTML;
          const content = item.querySelector<HTMLElement>("[data-collapsible-content]").innerHTML;

          render(<Accordion title={title} content={content} />, item.parentElement);
        }
      })
    );
  });

  // have the observer observe foo for changes in children
  mutationObserver.observe(document.body, { childList: true, subtree: true });
};
