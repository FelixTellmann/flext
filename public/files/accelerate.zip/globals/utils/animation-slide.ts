export const initAnimationSlide = () => {
  window.addEventListener("resize", handleResize);
  handleResize();
};

const handleResize = () => {
  const containerWidth = document.querySelector("[data-animation-slide-width]")?.clientWidth;

  document.querySelectorAll<HTMLElement>("[data-animation-slide]").forEach((slide) => {
    const content = slide.querySelector<HTMLElement>("[data-animation-slide-content]");
    const duplicate = slide.querySelector<HTMLElement>("[data-animation-slide-duplicate]");

    if (content.clientWidth > containerWidth) {
      slide.classList.add("animate-slide");
      duplicate.classList.remove("hidden");
    }

    if (content.clientWidth <= containerWidth) {
      slide.classList.remove("animate-slide");
      duplicate.classList.add("hidden");
    }
  });
};
