import { cart } from "globals/utils/cart";
import { _Cart_fetch_api, _Cart_fetch_api_Items } from "globals/utils/types";
import { JSONParse } from "globals/utils/utils";
import produce from "immer";
import localForage from "localforage";
import { SettingsSchema } from "types/settings";
import { _Product_liquid, _Variant_liquid } from "types/shopify";
import { create } from "zustand";
import { createJSONStorage, persist, StateStorage } from "zustand/middleware";
import { createStore } from "zustand/vanilla";

export const globalSettings = createStore<SettingsSchema>((set, get) => {
  /*Initial State*/
  return {
    ...window.theme_settings,
  };
});
export const useGlobalSettings = create(globalSettings);

type GlobalProductsState = {
  hydrated?: boolean;
  recentlyViewed: (number | string)[];
  products: { [T: string]: _Product_liquid & { timestamp?: number } };
  preloadProduct: (
    id: number | string,
    url: string
  ) => Promise<_Product_liquid & { timestamp?: number }>;
  getProduct: (id: number | string) => _Product_liquid & { timestamp?: number };
  setProduct: (product: _Product_liquid) => void;
};
export const globalProducts = createStore(
  persist<GlobalProductsState>(
    (set, get) => {
      return {
        hydrated: false,
        products: {},
        recentlyViewed: [],
        setProduct: (product) => {
          set(
            produce<GlobalProductsState>((state) => {
              state.products = {
                ...state.products,
                [`${product.id}`]: {
                  ...product,
                  timestamp: Date.now(),
                },
              };
            })
          );
        },
        preloadProduct: async (id, url) => {
          const localProduct: _Product_liquid = JSONParse(
            document.querySelector(`[data-product-json="${id}"]`)?.innerHTML
          );

          if (localProduct) {
            set(
              produce<GlobalProductsState>((state) => {
                state.products = {
                  ...state.products,
                  [`${localProduct.id}`]: {
                    ...localProduct,
                    timestamp: Date.now(),
                  },
                };
              })
            );
            return {
              ...localProduct,
              timestamp: Date.now(),
            };
          }

          const product = get().products[`${id}`];

          if (product && product.timestamp && Date.now() - product.timestamp < 1000 * 60 * 10) {
            return product;
          }

          const data = await fetch(
            `${window.Shopify.routes.root + url.replace(/^\//gi, "")}?sections=product-data`
          );
          const content = await data.json();
          const dataElement = document.createElement("div");
          dataElement.innerHTML = content["product-data"];
          const productData = JSONParse<_Product_liquid>(
            dataElement.querySelector("script")?.innerHTML
          );

          set(
            produce<GlobalProductsState>((state) => {
              if (productData) {
                state.products = {
                  ...state.products,
                  [`${productData.id}`]: {
                    ...productData,
                    timestamp: Date.now(),
                  },
                };
              }
              if (!productData) {
                delete state.products[`${id}`];
              }
            })
          );
          return {
            ...productData,
            timestamp: Date.now(),
          };
        },
        getProduct: (id) => {
          const localProduct: _Product_liquid = JSONParse(
            document.querySelector(`[data-product-json="${id}"]`)?.innerHTML
          );

          if (localProduct) {
            if (get().hydrated) {
              set(
                produce<GlobalProductsState>((state) => {
                  state.products = {
                    ...state.products,
                    [`${localProduct.id}`]: {
                      ...localProduct,
                      timestamp: Date.now(),
                    },
                  };
                })
              );
            }

            return {
              ...localProduct,
              timestamp: Date.now(),
            };
          }

          const product = get().products[id];

          if (!product) {
            return null;
          }
          if (product.timestamp && Date.now() - product.timestamp < 1000 * 60 * 10) {
            return product;
          }
          get().preloadProduct(id, product.url);
          return product;
        },
      };
    },
    {
      name: "accelerate-products",
      storage: createJSONStorage(() => localForage as unknown as StateStorage),
      onRehydrateStorage: (state) => {
        return (state2, error) => {
          if (error) {
            console.log("an error happened during hydration", error);
          } else {
            console.log("hydration finished", state2);
            globalProducts.setState({ hydrated: true });
          }
        };
      },
      // getStorage: () => customStorage as unknown as StateStorage,
    }
  )
);

export const useGlobalProducts = create(globalProducts);
export type CartDrawerState = {
  loading: boolean;
  cartData: _Cart_fetch_api | null;
  initCart: () => Promise<void>;
  addItem: (variant: Pick<_Variant_liquid, "id" | "image">, quantity: number) => Promise<void>;
  adjustItem: (lineItem: _Cart_fetch_api_Items, quantity: number) => void;
  updates: { [T: string | number]: number } | null;
  fetchUpdates: () => Promise<void>;
};

export const cartDrawer = createStore<CartDrawerState>((set, get) => {
  /*Initial State*/
  const cartData = JSONParse(
    document.querySelector("[data-cart-data]")?.innerHTML
  ) as _Cart_fetch_api;
  console.log({ cartData });

  return {
    loading: true,
    cartData: cartData,
    updates: null,
    initCart: async () => {
      set({ loading: true });
      set({ cartData: await cart.get(), loading: false });
    },
    adjustItem: (lineItem, quantity) => {
      const newQuantity = Math.max(0, lineItem.quantity + quantity);
      set(({ cartData, updates }) => {
        const newItemCount = cartData.item_count - lineItem.quantity + newQuantity;
        const newFinalLinePrice = lineItem.final_price * newQuantity;
        const newOriginalLinePrice = lineItem.original_price * newQuantity;

        return {
          loading: true,
          cartData: {
            ...cartData,
            item_count: newItemCount,
            total_price: cartData.total_price - lineItem.final_line_price + newFinalLinePrice,
            items: cartData.items.map((line_item) => {
              if (lineItem.key !== line_item.key) {
                return line_item;
              }
              return {
                ...line_item,
                quantity: newQuantity,
                final_line_price: newFinalLinePrice,
                original_line_price: newOriginalLinePrice,
              };
            }),
          },
          updates: {
            ...updates,
            [lineItem.key]: newQuantity,
          },
        };
      });
    },
    fetchUpdates: async () => {
      const data = await cart.update({
        updates: get().updates,
      });
      set({ cartData: data, loading: false, updates: null });
    },
    addItem: async (variant, quantity) => {},
  };
});
export const useLineItems = create(cartDrawer);
