import { FocusElement, scrollToY, selectorString, trapFocus } from "globals/utils/utils";

export const initSlideInDrawers = () => {
  const header = document.querySelector<HTMLElement>(".header-position");
  document.querySelectorAll<HTMLElement>("[data-drawer]").forEach((root) => {
    const name = root.dataset.drawer;
    const drawer = {
      name,
      content: root.querySelector<HTMLElement>("[data-drawer-content]"),
      overlay: root.querySelector<HTMLElement>("[data-drawer-overlay]"),
      openButtons: document.querySelectorAll<HTMLElement>(`[data-drawer-open="${name}"]`),
      closeButtons: document.querySelectorAll<HTMLElement>(`[data-drawer-close="${name}"]`),
    };

    const closeDrawer = () => {
      document.dispatchEvent(new Event(`${name}:closed`));
      trapFocus(document.body);
      root.classList.remove("active");
      document.body.style.overflow = "";
      header.style.zIndex = "";
      root.style.zIndex = "";
      document.removeEventListener("click", handleClose);
      document.removeEventListener("keydown", handleKeydown);
    };

    const openDrawer = () => {
      document.querySelectorAll<HTMLElement>("[data-drawer]").forEach((otherRoot) => {
        if (otherRoot.classList.contains("active")) {
          console.log({ other: otherRoot.dataset.drawer });
          const otherName = otherRoot.dataset.drawer;
          document.dispatchEvent(new Event(`${otherName}:close`));
        }
      });

      document.dispatchEvent(new Event(`${name}:opened`));
      root.classList.add("active");

      trapFocus(drawer.content);
      drawer.content.querySelectorAll<FocusElement>(selectorString)[0]?.focus();
      drawer.content.querySelectorAll<FocusElement>(selectorString)[0]?.blur();
      document.body.style.overflow = "hidden";
      header.style.zIndex = "100";
      root.style.zIndex = "101";
      document.addEventListener("click", handleClose);
      document.addEventListener("keydown", handleKeydown);
      const scrollContainer = root.querySelector<HTMLElement>(`[class*="overflow-y-auto"]`);
      if (scrollContainer) {
        scrollToY(100, 0, scrollContainer);
      }
    };

    const handleKeydown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        closeDrawer();
      }
    };

    const handleClose = (e) => {
      const outsideClick =
        !drawer.content.contains(e.target) &&
        ![...drawer.closeButtons].some((el) => el.contains(e.target)) &&
        ![...drawer.closeButtons].some((el) => el === e.target) &&
        ![...drawer.openButtons].some((el) => el.contains(e.target)) &&
        ![...drawer.openButtons].some((el) => el === e.target) &&
        !document.elementsFromPoint(e.x, e.y).some((el) => el === drawer.content);

      if (outsideClick) {
        closeDrawer();
      }
    };

    document.addEventListener(`${name}:open`, openDrawer);
    document.addEventListener(`${name}:close`, closeDrawer);

    drawer.openButtons.forEach((el) => {
      el.addEventListener("click", openDrawer);
    });
    drawer.closeButtons.forEach((el) => {
      el.addEventListener("click", closeDrawer);
    });
  });
};
