import { colorGroups } from "globals/settings/color-groups";
import { fontGroups } from "globals/settings/font-groups";
import { sectionGlobals } from "globals/settings/section-globals";
import { grayScale } from "globals/settings/gray-scale";
import { grayScaleStyle } from "globals/settings/gray-scale-style";
import { typeRange } from "globals/settings/type-range";
import { ShopifySettings } from "types/shopify";

export const settingsSchema: ShopifySettings = [
  {
    name: "theme_info",
    theme_name: "Accelerate",
    theme_author: "Framework Labs",
    theme_version: "0.0.1",
    theme_documentation_url: "https://help.shopify.com/manual/online-store/themes",
    theme_support_url: "https://support.shopify.com/",
  },
  {
    name: "Branding",
    settings: [
      {
        type: "header",
        content: "Logo",
      },
      {
        type: "image_picker",
        id: "branding_logo_dark_on_light",
        label: "Dark on light background",
      },
      {
        type: "image_picker",
        id: "branding_logo_light_on_dark",
        label: "Dark on light background",
      },
      {
        type: "header",
        content: "Favicon",
      },
      {
        type: "image_picker",
        id: "branding_favicon",
        label: "Favicon image",
        info: "Will be scaled down to 32 x 32px",
      },
    ],
  },
  {
    name: "Layout",
    settings: [
      {
        type: "checkbox",
        id: "layout_is_fullwidth",
        label: "Full-width Layout",
        default: false,
      },
      {
        type: "range",
        id: "layout_page_width",
        min: 960,
        max: 1920,
        step: 20,
        default: 1440,
        unit: "px",
        label: "Page width",
        info: "Requires Full-width disabled",
      },
      {
        type: "range",
        id: "layout_section_padding_sm",
        label: "Section Padding: Small",
        default: 32,
        min: 4,
        max: 64,
        step: 4,
        unit: "px",
      },
      {
        type: "range",
        id: "layout_section_padding_md",
        label: "Section Padding: Medium",
        default: 96,
        min: 48,
        max: 192,
        step: 4,
        unit: "px",
      },
      {
        type: "range",
        id: "layout_section_padding_lg",
        label: "Section Padding: Large",
        default: 240,
        min: 150,
        max: 500,
        step: 10,
        unit: "px",
      },
    ],
  },
  {
    name: "Colors Theme",
    settings: [
      {
        type: "header",
        content: "Global theme colors",
      },
      {
        ...sectionGlobals.colorScheme,
        default: "bg-theme-bg text-theme-text color-group-1",
        options: [
          ...sectionGlobals.colorScheme.options.filter(
            (option) => option.value !== "bg-theme-bg text-theme-text color-inherit"
          ),
        ],
      },
      {
        type: "header",
        content: "Theme Grayscale",
      },
      grayScale,
      grayScaleStyle,
      {
        type: "header",
        content: "Utility Colors",
      },
      {
        type: "color",
        id: "color_error",
        label: "Error",
        default: "#fc0000",
      },
      {
        type: "color",
        id: "color_warning",
        label: "Warning",
        default: "#f59e0b",
      },
      {
        type: "color",
        id: "color_success",
        label: "Success",
        default: "#22c55e",
      },
      {
        type: "color",
        id: "color_info",
        label: "Info",
        default: "#38bdf8",
      },
      {
        type: "color",
        id: "color_review_stars",
        label: "Review Stars",
        default: "#f3e008",
      },
    ],
  },
  colorGroups(1, "Default"),
  colorGroups(2, "Light on Dark"),
  colorGroups(3, "Header / Footer / Cart"),
  {
    name: "Typography",
    settings: [
      ...fontGroups({
        default_tag: "p",
        name: "Body",
        min: 14,
        max: 20,
        default_size: 16,
        weight: 400,
        line_height: 165,
        sm_min: 13,
        sm_max: 20,
        sm_default_size: 16,
      }),
      ...fontGroups({
        default_tag: "h1",
        name: "Heading 1",
        min: 32,
        max: 192,
        default_size: 128,
        step: 2,
        weight: 700,
        line_height: 105,
        sm_min: 20,
        sm_max: 128,
        sm_default_size: 48,
      }),
      ...fontGroups({
        default_tag: "h2",
        name: "Heading 2",
        min: 24,
        max: 128,
        default_size: 72,
        step: 2,
        weight: 700,
        line_height: 110,
        sm_min: 16,
        sm_max: 128,
        sm_default_size: 36,
      }),
      ...fontGroups({
        default_tag: "h3",
        name: "Heading 3",
        min: 14,
        max: 96,
        default_size: 36,
        weight: 600,
        line_height: 110,
        sm_min: 14,
        sm_max: 96,
        sm_default_size: 24,
      }),
      ...fontGroups({
        default_tag: "h4",
        name: "Heading 4",
        min: 14,
        max: 96,
        default_size: 28,
        weight: 500,
        line_height: 120,
        sm_min: 14,
        sm_max: 96,
        sm_default_size: 20,
      }),
      ...fontGroups({
        default_tag: "h5",
        name: "Heading 5",
        min: 12,
        max: 64,
        default_size: 18,
        weight: 300,
        line_height: 130,
        sm_min: 12,
        sm_max: 64,
        sm_default_size: 16,
      }),
      ...fontGroups({
        default_tag: "h6",
        name: "Heading 6",
        min: 12,
        max: 64,
        default_size: 18,
        weight: 300,
        line_height: 130,
        sm_min: 12,
        sm_max: 64,
        sm_default_size: 16,
      }),
      {
        type: "paragraph",
        content:
          "Selecting a different font can affect the speed of your store. [Learn more about system fonts.](https://help.shopify.com/manual/online-store/os/store-speed/improving-speed#fonts)",
      },
    ],
  },
  {
    name: "Buttons",
    settings: [
      {
        type: "header",
        content: "Typography",
      },
      {
        type: `font_picker` as const,
        id: `font_button`,
        label: `Font Family`,
        default: `helvetica_n4`,
      },
      {
        type: `text` as const,
        id: `font_button_custom`,
        label: `Custom font family`,
      },
      {
        type: `range` as const,
        id: `font_button_size`,
        label: `Desktop Font Size`,
        default: 16,
        min: 12,
        max: 24,
        step: 1,
        unit: `px`,
      },
      {
        type: `range` as const,
        id: `font_button_mobile_size`,
        label: `Mobile Font Size`,
        default: 16,
        min: 12,
        max: 24,
        step: 1,
        unit: `px`,
      },
      {
        type: `range` as const,
        id: `font_button_weight`,
        label: `Font Weight`,
        default: 500,
        min: 100,
        max: 900,
        step: 100,
      },
      {
        type: `range` as const,
        id: `font_button_letter_spacing`,
        label: `Letter Spacing`,
        default: 0,
        min: -10,
        max: 10,
        step: 1,
        unit: "%",
      },
      {
        type: "select",
        id: "button_text_transform",
        label: "Letter Casing",
        default: "none",
        options: [
          {
            value: "none",
            label: "None",
          },
          {
            value: "uppercase",
            label: "Uppercase",
          },
          {
            value: "lowercase",
            label: "Lowercase",
          },
          {
            value: "capitalize",
            label: "Capitalize",
          },
        ],
      },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Styling",
      },
      {
        type: "range",
        id: "button_horizontal_padding",
        label: "Horizontal Padding",
        default: 8,
        min: 4,
        max: 64,
        step: 4,
        unit: "px",
      },
      {
        type: "range",
        id: "button_vertical_padding",
        label: "Vertical Padding",
        default: 8,
        min: 2,
        max: 16,
        step: 2,
        unit: "px",
      },
      {
        type: "range",
        id: "button_border_radius",
        label: "Corner Radius",
        default: 0,
        min: -1,
        max: 20,
        step: 1,
        unit: "px",
        info: "Set to -1 to create a fully rounded-theme border",
      },
      {
        type: "range",
        id: "button_border_width",
        label: "Border Width",
        default: 1,
        min: 0,
        max: 6,
        step: 1,
        unit: "px",
      },
      {
        type: "range",
        id: "button_shadow",
        label: "Shadow",
        default: 0,
        min: 0,
        max: 6,
        step: 1,
      },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Hover Transition",
      },
      {
        type: "range",
        id: "button_hover_border_radius",
        label: "Corner Radius",
        default: 0,
        min: -1,
        max: 20,
        step: 1,
        unit: "px",
        info: "Set to the default Corner Radius to disable",
      },
      {
        type: "range",
        id: "button_hover_scale",
        label: "Scale",
        default: 100,
        min: 80,
        max: 130,
        step: 5,
        unit: "%",
      },
      {
        type: "range",
        id: "button_hover_shadow",
        label: "shadow",
        default: 0,
        min: 0,
        max: 6,
        step: 1,
      },
    ],
  },
  {
    name: "Design Elements",
    settings: [
      {
        type: "header",
        content: "Design Style",
      },
      {
        type: "radio",
        id: "design_border_radius",
        label: "Corner Styles",
        default: "soft",
        options: [
          {
            value: "soft",
            label: "Soft (Very round corners)",
          },
          {
            value: "medium",
            label: "Medium (A few round corners)",
          },
          {
            value: "bold",
            label: "Bold (No rounded-theme corners)",
          },
        ],
      },
      {
        type: "header",
        content: "Pagination",
      },
      {
        type: "radio",
        id: "design_pagination_style",
        label: "Style",
        default: "compact",
        options: [
          {
            value: "compact",
            label: "Compact",
          },
          {
            value: "floating",
            label: "Floating",
          },
        ],
      },
    ],
  },
  /*{
    name: "Variant pills",
    settings: [
      {
        type: "paragraph",
        content:
          "Variant pills are one way of displaying your product variants. [Learn more](https://help.shopify.com/en/manual/online-store/themes/theme-structure/page-types#variant-picker-block)",
      },
    ],
  },*/
  /*{
    name: "Inputs",
    settings: [
      {
        type: "header",
        content: "Border",
      },
    ],
  },*/
  {
    name: "Product Card",
    settings: [
      {
        type: "header",
        content: "Card style",
      },
      {
        type: "color",
        id: "product_card__background_color",
        label: "Background Color",
      },
      {
        type: "header",
        content: "Image",
      },
      {
        id: "product_card__image__ratio",
        type: "select",
        default: "pb-[125%]",
        options: [
          {
            value: "pb-[100%]",
            label: "Square (1:1)",
          },
          {
            value: "pb-[125%]",
            label: "Portrait (4:5)",
          },
          {
            value: "pb-[133%]",
            label: "Tall Portrait (4:3)",
          },
          {
            value: "pb-[177%]",
            label: "Story (9:16)",
          },
        ],
        label: "Image ratio",
      },
      {
        id: "product_card__image__show_secondary",
        type: "checkbox",
        default: false,
        label: "Show second image on hover",
      },
      {
        type: "checkbox" as const,
        id: "product_card__image__drop_shadow",
        label: "Add a drop shadow to the image",
        info: "Transparent images only",
        default: false,
      },
      {
        type: "color_background",
        id: "product_card__image__background",
        label: "Image background",
        default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
      },
      { ...sectionGlobals.marginBottom, id: "product_card__image__margin_bottom" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Labels",
      },
      {
        content:
          "You can setup custom labels via product metafields using `metafields.accelerate.product_labels` as a list of single line text.",
        type: "paragraph",
      },
      {
        type: "checkbox",
        id: "product_card__labels__show",
        label: "Show Labels",
      },
      {
        type: "radio",
        id: "product_card__labels__discount",
        label: "Discount Label type",
        info: "Shows when a product has a higher compare at price than the price field.",
        default: "sale",
        options: [
          {
            value: "sale",
            label: "On Sale",
          },
          {
            value: "percentage",
            label: "Discount Percentage",
          },
          {
            value: "value",
            label: "Discount Value",
          },
        ],
      },
      { ...sectionGlobals.responsiveVisibility, id: "product_card__labels__responsive_visibility" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Variant Quantity Display",
      },
      {
        type: "checkbox",
        id: "product_card__variant_count__show",
        label: "Show Variant Count",
      },
      {
        ...sectionGlobals.responsiveVisibility,
        id: "product_card__variant_count__responsive_visibility",
      },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Title",
      },
      typeRange({ id: "product_card__title__type", default_font: 4, label: "Title Type" }),
      { ...sectionGlobals.marginBottom, id: "product_card__title__margin_bottom" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Reviews",
      },
      {
        type: "checkbox",
        id: "product_card__rating__show",
        label: "Show Reviews",
      },
      { ...sectionGlobals.marginBottom, id: "product_card__rating__margin_bottom" },
      { ...sectionGlobals.responsiveVisibility, id: "product_card__rating__responsive_visibility" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Vendor",
      },
      {
        type: "checkbox",
        id: "product_card__vendor__show",
        label: "Show Vendor",
      },
      { ...sectionGlobals.marginBottom, id: "product_card__vendor__margin_bottom" },
      { ...sectionGlobals.responsiveVisibility, id: "product_card__vendor__responsive_visibility" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Price",
      },
      {
        type: "checkbox",
        id: "product_card__price__show",
        label: "Show Price",
      },
      { ...sectionGlobals.marginBottom, id: "product_card__price__margin_bottom" },
      { ...sectionGlobals.responsiveVisibility, id: "product_card__price__responsive_visibility" },
      {
        type: "paragraph" as const,
        content: " ",
      },
      {
        type: "header",
        content: "Variant Selector",
      },
      {
        type: "checkbox",
        id: "product_card__variant_selector__show",
        label: "Show Color Variant Selector",
      },

      {
        type: "textarea",
        id: "product_card__variant_selector__color_list",
        label: "Match product Options",
        default: "color,colour,couleur,cor,colore,farbe,색,色,カラー,färg,farve,szín,barva",
        info: "Comma seperated list of colors",
      },
      {
        type: "header",
        content: "Button",
      },
      {
        type: "radio",
        id: "product_card__button__style",
        label: "Style",
        default: "button-primary",
        options: [
          {
            value: "button-primary",
            label: "Primary",
          },
          {
            value: "button-primary--outline",
            label: "Primary Outline",
          },
          {
            value: "button-secondary",
            label: "Secondary",
          },
          {
            value: "button-secondary--outline",
            label: "Secondary Outline",
          },
        ],
      },
      {
        type: "paragraph" as const,
        content: " ",
      },
    ],
  },
  /*{
    name: "Collection cards",
    settings: [
      {
        type: "select",
        id: "collection_card_style",
        options: [
          {
            value: "standard",
            label: "Standard",
          },
          {
            value: "card",
            label: "Card",
          },
        ],
        default: "standard",
        label: "Style",
      },
    ],
  },*/
  /*{
    name: "Blog cards",
    settings: [
      {
        type: "select",
        id: "blog_card_style",
        options: [
          {
            value: "standard",
            label: "Standard",
          },
          {
            value: "card",
            label: "Card",
          },
        ],
        default: "standard",
        label: "Style",
      },
    ],
  },*/
  /*{
    name: "Content containers",
    settings: [
      {
        type: "header",
        content: "Border",
      },
    ],
  },*/
  /*{
    name: "Media",
    settings: [
      {
        type: "header",
        content: "Border",
      },
    ],
  },*/
  /*{
    name: "Dropdowns and pop-ups",
    settings: [
      {
        type: "paragraph",
        content: "Affects areas like navigation dropdowns, pop-up modals, and cart pop-ups.",
      },
    ],
  },*/
  /*{
    name: "Drawers",
    settings: [
      {
        type: "header",
        content: "Border",
      },
    ],
  },*/
  /*{
    name: "Badges",
    settings: [
      {
        type: "select",
        id: "badge_position",
        options: [
          {
            value: "bottom left",
            label: "Bottom left",
          },
          {
            value: "bottom right",
            label: "Bottom right",
          },
          {
            value: "top left",
            label: "Top left",
          },
          {
            value: "top right",
            label: "Top right",
          },
        ],
        default: "bottom left",
        label: "Position on cards",
      },
    ],
  },*/
  /*{
    name: "Icons",
    settings: [],
  },*/
  {
    name: "Social media",
    settings: [
      {
        type: "header",
        content: "Social accounts",
      },
      {
        type: "text",
        id: "social_twitter_link",
        label: "Twitter",
        info: "https://twitter.com/shopify",
      },
      {
        type: "text",
        id: "social_facebook_link",
        label: "Facebook",
        info: "https://facebook.com/shopify",
      },
      {
        type: "text",
        id: "social_pinterest_link",
        label: "Pinterest",
        info: "https://pinterest.com/shopify",
      },
      {
        type: "text",
        id: "social_instagram_link",
        label: "Instagram",
        info: "https://instagram.com/shopify",
      },
      {
        type: "text",
        id: "social_tiktok_link",
        label: "TikTok",
        info: "https://tiktok.com/@shopify",
      },
      {
        type: "text",
        id: "social_tumblr_link",
        label: "Tumblr",
        info: "https://shopify.tumblr.com",
      },
      {
        type: "text",
        id: "social_snapchat_link",
        label: "Snapchat",
        info: "https://www.snapchat.com/add/shopify",
      },
      {
        type: "text",
        id: "social_youtube_link",
        label: "YouTube",
        info: "https://www.youtube.com/shopify",
      },
      {
        type: "text",
        id: "social_vimeo_link",
        label: "Vimeo",
        info: "https://vimeo.com/shopify",
      },
    ],
  },
  {
    name: "Search behavior",
    settings: [
      {
        type: "header",
        content: "Product suggestions",
      },
      {
        type: "checkbox",
        id: "predictive_search_enabled",
        default: true,
        label: "Enable product suggestions",
      },
      {
        type: "checkbox",
        id: "predictive_search_show_vendor",
        default: false,
        label: "Show vendor",
        info: "Visible when product suggestions enabled.",
      },
      {
        type: "checkbox",
        id: "predictive_search_show_price",
        default: false,
        label: "Show price",
        info: "Visible when product suggestions enabled.",
      },
    ],
  },
  {
    name: "Currency format",
    settings: [
      {
        type: "header",
        content: "Currency codes",
      },
      {
        type: "paragraph",
        content: "Cart and checkout prices always show currency codes. Example: $1.00 USD.",
      },
      {
        type: "checkbox",
        id: "currency_code_enabled",
        label: "Show currency codes",
        default: true,
      },
    ],
  },
  {
    name: "Cart",
    settings: [
      {
        type: "select",
        id: "cart_type",
        options: [
          {
            value: "drawer",
            label: "Drawer",
          },
          {
            value: "page",
            label: "Page",
          },
        ],
        default: "drawer",
        label: "Cart type",
      },
      {
        type: "checkbox",
        id: "cart_gift_checkbox",
        label: "Enable gift checkbox",
        default: true,
      },
      {
        type: "checkbox",
        id: "cart_note",
        label: "Enable cart note",
        default: true,
      },
      {
        type: "header",
        content: "Cart Drawer Settings",
      },
      {
        ...sectionGlobals.colorScheme,
        id: "cart_color_scheme",
      },
    ],
  },
];
