import { _Image_liquid, _Product_liquid, _Color_liquid, _Collection_liquid, _Page_liquid, _Linklist_liquid } from "./shopify";

export type AppsSection = {
  blocks: AppsBlocks[];
  global: boolean;
  id: string;
  type: "apps";
};

export type AppsBlocksApp = {
  id: string;
  type: "@app";
};

export type AppsBlocks = AppsBlocksApp;

export type BenefitTabsSection = {
  blocks: BenefitTabsBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: radio */
    layout: "order-2" | "-order-1";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  };
  type: "benefit-tabs";
};

export type BenefitTabsBlocksBenefit = {
  id: string;
  settings: {
    /** Input type: range */
    title_font: number;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: text */
    title?: string;
  };
  type: "benefit";
};

export type BenefitTabsBlocks = BenefitTabsBlocksBenefit;

export type CartDrawerSection = {
  blocks: CartDrawerBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: range */
    announcements__height: number;
    /** Input type: radio */
    announcements__show: "all" | "header" | "cart" | "disable";
    /** Input type: checkbox */
    cart__recommended_products__enable: boolean;
    /** Input type: select */
    free_shipping_bar__color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    free_shipping_bar__height: number;
    /** Input type: radio */
    free_shipping_bar__show: "all" | "header" | "cart" | "disable";
    /** Input type: range */
    free_shipping_bar__starting_percentage: number;
    /** Input type: radio */
    free_shipping_bar__type: "item_count" | "total_price";
    /** Input type: product_list */
    cart__recommended_products?: _Product_liquid[];
    /** Input type: number */
    free_shipping_bar__target?: number;
  };
  type: "header-cart-promotions";
};

export type CartDrawerBlocksAnnouncement = {
  id: string;
  settings: {
    /** Input type: range */
    display_duration: number;
    /** Input type: select */
    position: "left" | "center" | "right";
    /** Input type: checkbox */
    scheduled: boolean;
    /** Input type: color */
    color_bg?: _Color_liquid | string;
    /** Input type: color */
    color_text?: _Color_liquid | string;
    /** Input type: text */
    end_date?: string;
    /** Input type: url */
    link?: string;
    /** Input type: richtext */
    short_text?: `<p${string}</p>`;
    /** Input type: text */
    start_date?: string;
    /** Input type: richtext */
    text?: `<p${string}</p>`;
  };
  type: "announcement";
};

export type CartDrawerBlocks = CartDrawerBlocksAnnouncement;

export type CollectionNavSection = {
  blocks: CollectionNavBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    aspect_ratio: "pb-[100%]" | "pb-[125%]" | "pb-[133%]" | "pb-[177%]";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    min_width_desktop: number;
    /** Input type: range */
    min_width_mobile: number;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: range */
    title_type: number;
    /** Input type: text */
    collection_image_metafield?: string;
    /** Input type: color_background */
    overlay?: string;
  };
  type: "collection-nav";
};

export type CollectionNavBlocksText = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type CollectionNavBlocksAccent_line = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    width: number;
    /** Input type: color */
    color?: _Color_liquid | string;
  };
  type: "accent_line";
};

export type CollectionNavBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type CollectionNavBlocksTab_group = {
  id: string;
  settings: {
    /** Input type: collection_list */
    collection_list?: _Collection_liquid[];
    /** Input type: text */
    collection_metafield?: string;
    /** Input type: text */
    tab?: string;
  };
  type: "tab_group";
};

export type CollectionNavBlocks =
  | CollectionNavBlocksText
  | CollectionNavBlocksAccent_line
  | CollectionNavBlocksButtons
  | CollectionNavBlocksTab_group;

export type CustomLiquidSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: liquid */
    custom_liquid?: string;
  };
  type: "custom-liquid";
};

export type CustomProductAndrewsSection = {
  blocks: CustomProductAndrewsBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    breadcrumbs__show: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: radio */
    gallery__layout: "horizontal" | "vertical" | "grid";
    /** Input type: checkbox */
    gallery__loop_videos: boolean;
    /** Input type: checkbox */
    gallery__show_thumbnails: boolean;
    /** Input type: radio */
    gallery__size: "small" | "medium" | "large";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: checkbox */
    sticky: boolean;
  };
  type: "custom-product-andrews";
};

export type CustomProductAndrewsBlocksApp = {
  id: string;
  type: "@app";
};

export type CustomProductAndrewsBlocksText = {
  id: string;
  settings: {
    /** Input type: richtext */
    text?: `<p${string}</p>`;
  };
  type: "text";
};

export type CustomProductAndrewsBlocksTitle = {
  id: string;
  settings: {
    /** Input type: range */
    font_scale: number;
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "title";
};

export type CustomProductAndrewsBlocksVendor = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "vendor";
};

export type CustomProductAndrewsBlocksPrice = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "price";
};

export type CustomProductAndrewsBlocksVariant_selector = {
  id: string;
  settings: {
    /** Input type: checkbox */
    color_selector: boolean;
    /** Input type: radio */
    default_type: "radio" | "select";
    /** Input type: checkbox */
    disable_unavailable: boolean;
    /** Input type: checkbox */
    image_selector: boolean;
    /** Input type: textarea */
    color_list?: string;
  };
  type: "variant_selector";
};

export type CustomProductAndrewsBlocksSku = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "sku";
};

export type CustomProductAndrewsBlocksQuantity_selector = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "quantity_selector";
};

export type CustomProductAndrewsBlocksBuy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "buy_buttons";
};

export type CustomProductAndrewsBlocksDynamic_buy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "dynamic_buy_buttons";
};

export type CustomProductAndrewsBlocksDescription = {
  id: string;
  settings: {
    /** Input type: checkbox */
    accordion_style: boolean;
  };
  type: "description";
};

export type CustomProductAndrewsBlocksDescription_tabs = {
  id: string;
  settings: {
    /** Input type: text */
    match_from_1?: string;
    /** Input type: text */
    match_from_2?: string;
    /** Input type: text */
    match_from_3?: string;
    /** Input type: text */
    match_to_1?: string;
    /** Input type: text */
    match_to_2?: string;
    /** Input type: text */
    match_to_3?: string;
    /** Input type: text */
    tab_title_1?: string;
    /** Input type: text */
    tab_title_2?: string;
    /** Input type: text */
    tab_title_3?: string;
  };
  type: "description_tabs";
};

export type CustomProductAndrewsBlocksShare = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "share";
};

export type CustomProductAndrewsBlocksCustom_liquid = {
  id: string;
  settings: {
    /** Input type: liquid */
    custom_liquid?: string;
  };
  type: "custom_liquid";
};

export type CustomProductAndrewsBlocksCollapsible_tab = {
  id: string;
  settings: {
    /** Input type: select */
    icon: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: text */
    heading?: string;
    /** Input type: page */
    page?: _Page_liquid | string;
  };
  type: "collapsible_tab";
};

export type CustomProductAndrewsBlocksRating = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "rating";
};

export type CustomProductAndrewsBlocksComplementary = {
  id: string;
  settings: {
    /** Input type: checkbox */
    image__show_secondary: boolean;
    /** Input type: product_list */
    products?: _Product_liquid[];
    /** Input type: text */
    title?: string;
  };
  type: "complementary";
};

export type CustomProductAndrewsBlocksIcon_with_text = {
  id: string;
  settings: {
    /** Input type: select */
    icon_1: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_2: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_3: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    layout: "flex-row" | "flex-col";
    /** Input type: range */
    size: number;
    /** Input type: text */
    heading_1?: string;
    /** Input type: text */
    heading_2?: string;
    /** Input type: text */
    heading_3?: string;
    /** Input type: image_picker */
    image_1?: _Image_liquid | string;
    /** Input type: image_picker */
    image_2?: _Image_liquid | string;
    /** Input type: image_picker */
    image_3?: _Image_liquid | string;
  };
  type: "icon_with_text";
};

export type CustomProductAndrewsBlocksInventory = {
  id: string;
  settings: {
    /** Input type: range */
    threshold: number;
  };
  type: "inventory";
};

export type CustomProductAndrewsBlocksImage = {
  id: string;
  settings: {
    /** Input type: select */
    grid_row_span: "row-span-1" | "row-span-2" | "row-span-3" | "row-span-4" | "row-span-5" | "row-span-6";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: checkbox */
    image__drop_shadow: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: color_background */
    image__background?: string;
  };
  type: "image";
};

export type CustomProductAndrewsBlocksPre_order = {
  id: string;
  settings: {
    /** Input type: radio */
    preorder_date: "estimate" | "precise" | "none";
  };
  type: "pre_order";
};

export type CustomProductAndrewsBlocksProduct_sibling = {
  id: string;
  settings: {
    /** Input type: radio */
    selector: "image" | "color" | "radio" | "select";
  };
  type: "product_sibling";
};

export type CustomProductAndrewsBlocks =
  | CustomProductAndrewsBlocksApp
  | CustomProductAndrewsBlocksText
  | CustomProductAndrewsBlocksTitle
  | CustomProductAndrewsBlocksVendor
  | CustomProductAndrewsBlocksPrice
  | CustomProductAndrewsBlocksVariant_selector
  | CustomProductAndrewsBlocksSku
  | CustomProductAndrewsBlocksQuantity_selector
  | CustomProductAndrewsBlocksBuy_buttons
  | CustomProductAndrewsBlocksDynamic_buy_buttons
  | CustomProductAndrewsBlocksDescription
  | CustomProductAndrewsBlocksDescription_tabs
  | CustomProductAndrewsBlocksShare
  | CustomProductAndrewsBlocksCustom_liquid
  | CustomProductAndrewsBlocksCollapsible_tab
  | CustomProductAndrewsBlocksRating
  | CustomProductAndrewsBlocksComplementary
  | CustomProductAndrewsBlocksIcon_with_text
  | CustomProductAndrewsBlocksInventory
  | CustomProductAndrewsBlocksImage
  | CustomProductAndrewsBlocksPre_order
  | CustomProductAndrewsBlocksProduct_sibling;

export type FaqSection = {
  blocks: FaqBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: select */
    width: "max-w-full" | "max-w-[var(--layout-page-width)]" | "max-w-3xl" | "max-w-2xl" | "max-w-xl" | "max-w-lg" | "max-w-md" | "max-w-sm";
    /** Input type: text */
    title?: string;
  };
  type: "faq";
};

export type FaqBlocksGroup = {
  id: string;
  settings: {
    /** Input type: text */
    title?: string;
  };
  type: "group";
};

export type FaqBlocksFaq = {
  id: string;
  settings: {
    /** Input type: richtext */
    answer?: `<p${string}</p>`;
    /** Input type: page */
    page?: _Page_liquid | string;
    /** Input type: text */
    title?: string;
  };
  type: "faq";
};

export type FaqBlocks =
  | FaqBlocksGroup
  | FaqBlocksFaq;

export type FeaturedCollectionGridSection = {
  blocks: FeaturedCollectionGridBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: collection */
    collection?: _Collection_liquid | string;
    /** Input type: product_list */
    products?: _Product_liquid[];
  };
  type: "featured-collection-grid";
};

export type FeaturedCollectionGridBlocksImage = {
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
  };
  type: "image";
};

export type FeaturedCollectionGridBlocksContent = {
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    preheading_font: number;
    /** Input type: range */
    subtitle_font: number;
    /** Input type: range */
    title_font: number;
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    preheading?: string;
    /** Input type: textarea */
    subtitle?: string;
    /** Input type: text */
    title?: string;
  };
  type: "content";
};

export type FeaturedCollectionGridBlocks =
  | FeaturedCollectionGridBlocksImage
  | FeaturedCollectionGridBlocksContent;

export type FeaturesSection = {
  blocks: FeaturesBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    layout: "icon-minimal" | "icon-flat" | "icon-cards" | "image-flat" | "image-column" | "story";
    /** Input type: richtext */
    description?: `<p${string}</p>`;
    /** Input type: text */
    preheading?: string;
    /** Input type: text */
    title?: string;
  };
  type: "features";
};

export type FeaturesBlocksFeature = {
  id: string;
  settings: {
    /** Input type: select */
    icon_list: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: textarea */
    svg?: string;
    /** Input type: text */
    title?: string;
    /** Input type: url */
    url?: string;
  };
  type: "feature";
};

export type FeaturesBlocks = FeaturesBlocksFeature;

export type FooterSection = {
  blocks: FooterBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    country_selector_show: boolean;
    /** Input type: checkbox */
    language_selector_show: boolean;
    /** Input type: select */
    logo: "branding_logo_dark_on_light" | "branding_logo_light_on_dark" | "branding_logo_none";
    /** Input type: range */
    logo_height: number;
    /** Input type: checkbox */
    newsletter_show: boolean;
    /** Input type: checkbox */
    payment_types_show: boolean;
    /** Input type: checkbox */
    policy_links_show: boolean;
    /** Input type: checkbox */
    social_icons_show: boolean;
    /** Input type: text */
    newsletter_heading?: string;
  };
  type: "footer";
};

export type FooterBlocksMenu = {
  id: string;
  settings: {
    /** Input type: text */
    heading?: string;
    /** Input type: link_list */
    menu?: _Linklist_liquid;
  };
  type: "menu";
};

export type FooterBlocksText = {
  id: string;
  settings: {
    /** Input type: radio */
    color_grayscale_style: "normal" | "inverted";
    /** Input type: text */
    heading?: string;
    /** Input type: richtext */
    subtext?: `<p${string}</p>`;
  };
  type: "text";
};

export type FooterBlocksImage = {
  id: string;
  settings: {
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type FooterBlocks =
  | FooterBlocksMenu
  | FooterBlocksText
  | FooterBlocksImage;

export type FormsSection = {
  blocks: FormsBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    fullwidth: boolean;
    /** Input type: checkbox */
    hide_if_account: boolean;
    /** Input type: select */
    redirect: "off" | "/" | "/account" | "/account/login" | "/account/login#recover" | "/account/register" | "/account/logout" | "/account/addresses" | "/cart";
    /** Input type: checkbox */
    show_only_on_target: boolean;
    /** Input type: select */
    type: "customer" | "customer_login" | "create_customer" | "customer_address" | "contact" | "reset_customer_password" | "recover_customer_password" | "activate_customer_password";
    /** Input type: select */
    width: "max-w-full" | "max-w-[var(--layout-page-width)]" | "max-w-3xl" | "max-w-2xl" | "max-w-xl" | "max-w-lg" | "max-w-md" | "max-w-sm";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: textarea */
    success_message?: string;
    /** Input type: text */
    target_id?: string;
  };
  type: "forms";
};

export type FormsBlocksText = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: radio */
    style: "h1" | "h2" | "h3" | "h4" | "preheading" | "richtext";
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type FormsBlocksSeparator = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
  };
  type: "separator";
};

export type FormsBlocksPassword = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: text */
    confirm_pw__title?: string;
    /** Input type: text */
    title?: string;
  };
  type: "password";
};

export type FormsBlocksEmail = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: text */
    placeholder?: string;
    /** Input type: text */
    title?: string;
  };
  type: "email";
};

export type FormsBlocksInput = {
  id: string;
  settings: {
    /** Input type: select */
    autocomplete: "off" | "name" | "honorific-prefix" | "given-name" | "additional-name" | "family-name" | "honorific-suffix" | "nickname" | "email" | "username" | "new-password" | "current-password" | "one-time-code" | "organization-title" | "organization" | "street-address" | "address-line1" | "address-line2" | "address-line3" | "address-level4" | "address-level3" | "address-level2" | "address-level1" | "country" | "country-name" | "postal-code" | "cc-name" | "cc-given-name" | "cc-additional-name" | "cc-family-name" | "cc-number" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-csc" | "cc-type" | "transaction-currency" | "transaction-amount" | "language" | "bday" | "bday-day" | "bday-month" | "bday-year" | "sex" | "tel" | "tel-country-code" | "tel-national" | "tel-area-code" | "tel-local" | "tel-extension" | "impp" | "url" | "photo";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: checkbox */
    required: boolean;
    /** Input type: radio */
    type: "text" | "tel" | "number" | "email" | "date" | "url" | "checkbox" | "hidden";
    /** Input type: text */
    name?: string;
    /** Input type: text */
    placeholder?: string;
    /** Input type: text */
    title?: string;
  };
  type: "input";
};

export type FormsBlocksHidden = {
  id: string;
  settings: {
    /** Input type: text */
    name?: string;
    /** Input type: text */
    value?: string;
  };
  type: "hidden";
};

export type FormsBlocksSelect = {
  id: string;
  settings: {
    /** Input type: checkbox */
    all_countries: boolean;
    /** Input type: text */
    name?: string;
    /** Input type: text */
    title?: string;
  };
  type: "select";
};

export type FormsBlocksInput_group = {
  id: string;
  settings: {
    /** Input type: radio */
    type: "radio" | "checkbox";
    /** Input type: text */
    name?: string;
    /** Input type: text */
    title?: string;
  };
  type: "Input_group";
};

export type FormsBlocksTextarea = {
  id: string;
  settings: {
    /** Input type: checkbox */
    required: boolean;
    /** Input type: range */
    rows: number;
    /** Input type: text */
    name?: string;
    /** Input type: text */
    placeholder?: string;
    /** Input type: text */
    title?: string;
  };
  type: "textarea";
};

export type FormsBlocksButtons = {
  id: string;
  settings: {
    /** Input type: checkbox */
    fullwidth: boolean;
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: checkbox */
    reset__show: boolean;
    /** Input type: text */
    reset__title?: string;
    /** Input type: text */
    title?: string;
  };
  type: "buttons";
};

export type FormsBlocks =
  | FormsBlocksText
  | FormsBlocksSeparator
  | FormsBlocksPassword
  | FormsBlocksEmail
  | FormsBlocksInput
  | FormsBlocksHidden
  | FormsBlocksSelect
  | FormsBlocksInput_group
  | FormsBlocksTextarea
  | FormsBlocksButtons;

export type HeaderSection = {
  blocks: HeaderBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    center_logo: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    force_hamburger_menu: boolean;
    /** Input type: range */
    height: number;
    /** Input type: select */
    logo: "branding_logo_dark_on_light" | "branding_logo_light_on_dark" | "branding_logo_none";
    /** Input type: range */
    logo_height: number;
    /** Input type: radio */
    position: "sticky" | "relative";
    /** Input type: link_list */
    menu?: _Linklist_liquid;
  };
  type: "header";
};

export type HeaderBlocksMegamenu = {
  id: string;
  settings: {
    /** Input type: range */
    font_scale: number;
    /** Input type: radio */
    rows: "1" | "2";
    /** Input type: checkbox */
    show_caption: boolean;
    /** Input type: checkbox */
    show_images: boolean;
    /** Input type: text */
    handle?: string;
    /** Input type: color */
    image_caption_color?: _Color_liquid | string;
    /** Input type: color_background */
    image_overlay?: string;
    /** Input type: text */
    override_1_handle?: string;
    /** Input type: image_picker */
    override_1_image?: _Image_liquid | string;
    /** Input type: text */
    override_2_handle?: string;
    /** Input type: image_picker */
    override_2_image?: _Image_liquid | string;
    /** Input type: text */
    override_3_handle?: string;
    /** Input type: image_picker */
    override_3_image?: _Image_liquid | string;
    /** Input type: text */
    override_4_handle?: string;
    /** Input type: image_picker */
    override_4_image?: _Image_liquid | string;
  };
  type: "megamenu";
};

export type HeaderBlocks = HeaderBlocksMegamenu;

export type ImageBannerSection = {
  blocks: ImageBannerBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
  };
  type: "image-banner";
};

export type ImageBannerBlocksText = {
  id: string;
  settings: {
    /** Input type: radio */
    style: "h1" | "h2" | "h3" | "h4" | "preheading" | "richtext";
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type ImageBannerBlocksImage = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type ImageBannerBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type ImageBannerBlocks =
  | ImageBannerBlocksText
  | ImageBannerBlocksImage
  | ImageBannerBlocksButtons;

export type ImageFeedSection = {
  blocks: ImageFeedBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    image__aspect_ratio: "pb-[75%]" | "pb-[100%]" | "pb-[125%]";
    /** Input type: range */
    min_width: number;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
  };
  type: "image-feed";
};

export type ImageFeedBlocksImage = {
  id: string;
  settings: {
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    subtitle_font: number;
    /** Input type: range */
    title_font: number;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: textarea */
    subtitle?: string;
    /** Input type: text */
    title?: string;
  };
  type: "image";
};

export type ImageFeedBlocks = ImageFeedBlocksImage;

export type ImageWithTextSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    image__aspect_ratio: "pb-[125%]" | "pb-[100%]" | "pb-[75%]";
    /** Input type: radio */
    image__order: "-order-1" | "order-2";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: range */
    preheading_font: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: range */
    subtitle_font: number;
    /** Input type: range */
    title_font: number;
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    preheading?: string;
    /** Input type: textarea */
    subtitle?: string;
    /** Input type: text */
    title?: string;
  };
  type: "image-with-text";
};

export type MainAccountSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
  };
  type: "account";
};

export type MainAddressesSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
  };
  type: "addresses";
};

export type MainArticleSection = {
  blocks: MainArticleBlocks[];
  global: boolean;
  id: string;
  type: "blog-post";
};

export type MainArticleBlocksApp = {
  id: string;
  type: "@app";
};

export type MainArticleBlocksFeatured_image = {
  id: string;
  settings: {
    /** Input type: select */
    image_height: "adapt" | "small" | "medium" | "large";
  };
  type: "featured_image";
};

export type MainArticleBlocksTitle = {
  id: string;
  settings: {
    /** Input type: checkbox */
    blog_show_author: boolean;
    /** Input type: checkbox */
    blog_show_date: boolean;
  };
  type: "title";
};

export type MainArticleBlocksContent = {
  id: string;
  type: "content";
};

export type MainArticleBlocksShare = {
  id: string;
  settings: {
    /** Input type: text */
    share_label?: string;
  };
  type: "share";
};

export type MainArticleBlocks =
  | MainArticleBlocksApp
  | MainArticleBlocksFeatured_image
  | MainArticleBlocksTitle
  | MainArticleBlocksContent
  | MainArticleBlocksShare;

export type MainBlogSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    author__show: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    date__show: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: checkbox */
    image__show: boolean;
    /** Input type: color_background */
    image__background?: string;
  };
  type: "blog-posts";
};

export type MainCartSection = {
  blocks: MainCartBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
  };
  type: "main-cart";
};

export type MainCartBlocksEmpty = {
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    min_height: number;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    no_display_title?: string;
    /** Input type: text */
    preheading?: string;
    /** Input type: textarea */
    subtitle?: string;
  };
  type: "empty";
};

export type MainCartBlocks = MainCartBlocksEmpty;

export type MainCollectionBannerSection = {
  blocks: MainCollectionBannerBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    height_desktop: number;
    /** Input type: range */
    height_mobile: number;
    /** Input type: checkbox */
    image__show: boolean;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: color_background */
    image__overlay?: string;
  };
  type: "collection-banner";
};

export type MainCollectionBannerBlocksTitle = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
  };
  type: "title";
};

export type MainCollectionBannerBlocksDescription = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
  };
  type: "description";
};

export type MainCollectionBannerBlocksProduct_count = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
  };
  type: "product_count";
};

export type MainCollectionBannerBlocks =
  | MainCollectionBannerBlocksTitle
  | MainCollectionBannerBlocksDescription
  | MainCollectionBannerBlocksProduct_count;

export type MainCollectionFilterSortBarSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    filters__count: boolean;
    /** Input type: checkbox */
    filters__show: boolean;
    /** Input type: select */
    filters__type: "megamenu" | "cards";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: checkbox */
    sort__show: boolean;
  };
  type: "filter-sort-bar";
};

export type MainCollectionProductGridSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    columns__desktop: "lg:grid-cols-1" | "lg:grid-cols-2" | "lg:grid-cols-3" | "lg:grid-cols-4" | "lg:grid-cols-5";
    /** Input type: select */
    columns__mobile: "grid-cols-1" | "grid-cols-2";
    /** Input type: range */
    pagination_size: number;
  };
  type: "product-grid";
};

export type MainCollectionsListSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    columns__desktop: "lg:grid-cols-1" | "lg:grid-cols-2" | "lg:grid-cols-3" | "lg:grid-cols-4" | "lg:grid-cols-5";
    /** Input type: select */
    columns__mobile: "grid-cols-1" | "grid-cols-2";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: range */
    pagination_size: number;
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
  };
  type: "main-collections-list";
};

export type MainOrderSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: range */
    padding_bottom: number;
    /** Input type: range */
    padding_top: number;
  };
  type: "order";
};

export type MainPageSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: select */
    width: "max-w-full" | "max-w-[var(--layout-page-width)]" | "max-w-3xl" | "max-w-2xl" | "max-w-xl" | "max-w-lg" | "max-w-md" | "max-w-sm";
  };
  type: "page";
};

export type MainSearchFiltersSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    filters__count: boolean;
    /** Input type: checkbox */
    filters__show: boolean;
    /** Input type: select */
    filters__type: "megamenu" | "cards";
    /** Input type: checkbox */
    sort__show: boolean;
  };
  type: "search-filter-sort-bar";
};

export type MainSearchGridSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    article_show_author: boolean;
    /** Input type: checkbox */
    article_show_date: boolean;
    /** Input type: select */
    columns__desktop: "lg:grid-cols-1" | "lg:grid-cols-2" | "lg:grid-cols-3" | "lg:grid-cols-4" | "lg:grid-cols-5";
    /** Input type: select */
    columns__mobile: "grid-cols-1" | "grid-cols-2";
    /** Input type: checkbox */
    image__drop_shadow: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: checkbox */
    image__show_secondary: boolean;
    /** Input type: radio */
    labels__discount: "sale" | "percentage" | "value";
    /** Input type: checkbox */
    labels__show: boolean;
    /** Input type: range */
    pagination_size: number;
    /** Input type: checkbox */
    rating__show: boolean;
    /** Input type: checkbox */
    vendor__show: boolean;
    /** Input type: color_background */
    image__background?: string;
  };
  type: "search-results";
};

export type MainSearchInputSection = {
  global: boolean;
  id: string;
  type: "search-bar-input";
};

export type Main404Section = {
  blocks: Main404Blocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    min_height: number;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
  };
  type: "main-404";
};

export type Main404BlocksText = {
  id: string;
  settings: {
    /** Input type: radio */
    style: "h1" | "h2" | "h3" | "h4" | "preheading" | "richtext";
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type Main404BlocksImage = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type Main404BlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type Main404Blocks =
  | Main404BlocksText
  | Main404BlocksImage
  | Main404BlocksButtons;

export type MarqueeBarSection = {
  blocks: MarqueeBarBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    auto_pause: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    duration: number;
    /** Input type: range */
    height: number;
    /** Input type: checkbox */
    highlight: boolean;
  };
  type: "marquee-bar";
};

export type MarqueeBarBlocksText = {
  id: string;
  settings: {
    /** Input type: textarea */
    text?: string;
    /** Input type: url */
    url?: string;
  };
  type: "text";
};

export type MarqueeBarBlocksImage = {
  id: string;
  settings: {
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: url */
    url?: string;
  };
  type: "image";
};

export type MarqueeBarBlocksSvg = {
  id: string;
  settings: {
    /** Input type: textarea */
    svg?: string;
    /** Input type: url */
    url?: string;
  };
  type: "svg";
};

export type MarqueeBarBlocks =
  | MarqueeBarBlocksText
  | MarqueeBarBlocksImage
  | MarqueeBarBlocksSvg;

export type NewsletterSection = {
  blocks: NewsletterBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: select */
    width: "max-w-full" | "max-w-[var(--layout-page-width)]" | "max-w-3xl" | "max-w-2xl" | "max-w-xl" | "max-w-lg" | "max-w-md" | "max-w-sm";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
  };
  type: "email-signup";
};

export type NewsletterBlocksEmail = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: text */
    button_text?: string;
    /** Input type: text */
    placeholder_text?: string;
    /** Input type: text */
    tag?: string;
  };
  type: "email";
};

export type NewsletterBlocksText = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type NewsletterBlocksImage = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type NewsletterBlocksAccent_line = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    width: number;
    /** Input type: color */
    color?: _Color_liquid | string;
  };
  type: "accent_line";
};

export type NewsletterBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type NewsletterBlocks =
  | NewsletterBlocksEmail
  | NewsletterBlocksText
  | NewsletterBlocksImage
  | NewsletterBlocksAccent_line
  | NewsletterBlocksButtons;

export type ObjectOverImageSection = {
  blocks: ObjectOverImageBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    spacing: number;
    /** Input type: range */
    title_type: number;
  };
  type: "object-over-image";
};

export type ObjectOverImageBlocksObject_position = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
  };
  type: "object_position";
};

export type ObjectOverImageBlocksObject = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    title?: string;
    /** Input type: url */
    url?: string;
  };
  type: "object";
};

export type ObjectOverImageBlocksText = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type ObjectOverImageBlocksAccent_line = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    width: number;
    /** Input type: color */
    color?: _Color_liquid | string;
  };
  type: "accent_line";
};

export type ObjectOverImageBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type ObjectOverImageBlocks =
  | ObjectOverImageBlocksObject_position
  | ObjectOverImageBlocksObject
  | ObjectOverImageBlocksText
  | ObjectOverImageBlocksAccent_line
  | ObjectOverImageBlocksButtons;

export type PasswordFooterSection = {
  blocks: PasswordFooterBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    country_selector_show: boolean;
    /** Input type: checkbox */
    language_selector_show: boolean;
    /** Input type: select */
    logo: "branding_logo_dark_on_light" | "branding_logo_light_on_dark" | "branding_logo_none";
    /** Input type: checkbox */
    newsletter_show: boolean;
    /** Input type: checkbox */
    payment_types_show: boolean;
    /** Input type: checkbox */
    policy_links_show: boolean;
    /** Input type: checkbox */
    social_icons_show: boolean;
    /** Input type: text */
    newsletter_heading?: string;
  };
  type: "password-footer";
};

export type PasswordFooterBlocksText = {
  id: string;
  settings: {
    /** Input type: radio */
    color_grayscale_style: "normal" | "inverted";
    /** Input type: text */
    heading?: string;
    /** Input type: richtext */
    subtext?: `<p${string}</p>`;
  };
  type: "text";
};

export type PasswordFooterBlocksImage = {
  id: string;
  settings: {
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type PasswordFooterBlocks =
  | PasswordFooterBlocksText
  | PasswordFooterBlocksImage;

export type PasswordHeaderSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    center_logo: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    height: number;
    /** Input type: select */
    logo: "branding_logo_dark_on_light" | "branding_logo_light_on_dark" | "branding_logo_none";
    /** Input type: range */
    logo_height: number;
    /** Input type: link_list */
    menu?: _Linklist_liquid;
  };
  type: "password-header";
};

export type PredictiveSearchSection = {
  global: boolean;
  id: string;
  type: "predictive-search";
};

export type ProductSection = {
  blocks: ProductBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    breadcrumbs__show: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: radio */
    gallery__layout: "horizontal" | "vertical" | "grid";
    /** Input type: checkbox */
    gallery__loop_videos: boolean;
    /** Input type: checkbox */
    gallery__show_thumbnails: boolean;
    /** Input type: radio */
    gallery__size: "small" | "medium" | "large";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    section_layout: "container-bg-full" | "fullwidth";
    /** Input type: checkbox */
    sticky: boolean;
  };
  type: "product";
};

export type ProductBlocksApp = {
  id: string;
  type: "@app";
};

export type ProductBlocksText = {
  id: string;
  settings: {
    /** Input type: richtext */
    text?: `<p${string}</p>`;
  };
  type: "text";
};

export type ProductBlocksTitle = {
  id: string;
  settings: {
    /** Input type: range */
    font_scale: number;
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "title";
};

export type ProductBlocksVendor = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "vendor";
};

export type ProductBlocksPrice = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "price";
};

export type ProductBlocksVariant_selector = {
  id: string;
  settings: {
    /** Input type: checkbox */
    color_selector: boolean;
    /** Input type: radio */
    default_type: "radio" | "select";
    /** Input type: checkbox */
    disable_unavailable: boolean;
    /** Input type: checkbox */
    image_selector: boolean;
    /** Input type: textarea */
    color_list?: string;
  };
  type: "variant_selector";
};

export type ProductBlocksSku = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "sku";
};

export type ProductBlocksQuantity_selector = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "quantity_selector";
};

export type ProductBlocksBuy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "buy_buttons";
};

export type ProductBlocksDynamic_buy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "dynamic_buy_buttons";
};

export type ProductBlocksDescription = {
  id: string;
  settings: {
    /** Input type: checkbox */
    accordion_style: boolean;
  };
  type: "description";
};

export type ProductBlocksShare = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "share";
};

export type ProductBlocksCustom_liquid = {
  id: string;
  settings: {
    /** Input type: liquid */
    custom_liquid?: string;
  };
  type: "custom_liquid";
};

export type ProductBlocksCollapsible_tab = {
  id: string;
  settings: {
    /** Input type: select */
    icon: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: text */
    heading?: string;
    /** Input type: page */
    page?: _Page_liquid | string;
  };
  type: "collapsible_tab";
};

export type ProductBlocksRating = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "rating";
};

export type ProductBlocksComplementary = {
  id: string;
  settings: {
    /** Input type: checkbox */
    image__show_secondary: boolean;
    /** Input type: product_list */
    products?: _Product_liquid[];
    /** Input type: text */
    title?: string;
  };
  type: "complementary";
};

export type ProductBlocksIcon_with_text = {
  id: string;
  settings: {
    /** Input type: select */
    icon_1: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_2: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_3: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    layout: "flex-row" | "flex-col";
    /** Input type: range */
    size: number;
    /** Input type: text */
    heading_1?: string;
    /** Input type: text */
    heading_2?: string;
    /** Input type: text */
    heading_3?: string;
    /** Input type: image_picker */
    image_1?: _Image_liquid | string;
    /** Input type: image_picker */
    image_2?: _Image_liquid | string;
    /** Input type: image_picker */
    image_3?: _Image_liquid | string;
  };
  type: "icon_with_text";
};

export type ProductBlocksInventory = {
  id: string;
  settings: {
    /** Input type: range */
    threshold: number;
  };
  type: "inventory";
};

export type ProductBlocksImage = {
  id: string;
  settings: {
    /** Input type: select */
    grid_row_span: "row-span-1" | "row-span-2" | "row-span-3" | "row-span-4" | "row-span-5" | "row-span-6";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: checkbox */
    image__drop_shadow: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: color_background */
    image__background?: string;
  };
  type: "image";
};

export type ProductBlocksPre_order = {
  id: string;
  settings: {
    /** Input type: radio */
    preorder_date: "estimate" | "precise" | "none";
  };
  type: "pre_order";
};

export type ProductBlocksProduct_sibling = {
  id: string;
  settings: {
    /** Input type: radio */
    selector: "image" | "color" | "radio" | "select";
  };
  type: "product_sibling";
};

export type ProductBlocks =
  | ProductBlocksApp
  | ProductBlocksText
  | ProductBlocksTitle
  | ProductBlocksVendor
  | ProductBlocksPrice
  | ProductBlocksVariant_selector
  | ProductBlocksSku
  | ProductBlocksQuantity_selector
  | ProductBlocksBuy_buttons
  | ProductBlocksDynamic_buy_buttons
  | ProductBlocksDescription
  | ProductBlocksShare
  | ProductBlocksCustom_liquid
  | ProductBlocksCollapsible_tab
  | ProductBlocksRating
  | ProductBlocksComplementary
  | ProductBlocksIcon_with_text
  | ProductBlocksInventory
  | ProductBlocksImage
  | ProductBlocksPre_order
  | ProductBlocksProduct_sibling;

export type ProductAddToCartBarSection = {
  blocks: ProductAddToCartBarBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: product */
    upsell_product?: _Product_liquid | string;
  };
  type: "add-to-cart-bar";
};

export type ProductAddToCartBarBlocksLink = {
  id: string;
  settings: {
    /** Input type: text */
    title?: string;
    /** Input type: url */
    url?: string;
  };
  type: "link";
};

export type ProductAddToCartBarBlocks = ProductAddToCartBarBlocksLink;

export type ProductDataSection = {
  global: boolean;
  id: string;
  type: "product-data";
};

export type ProductDrawerSection = {
  blocks: ProductDrawerBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    active: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
  };
  type: "product-drawer";
};

export type ProductDrawerBlocksImage = {
  id: string;
  settings: {
    /** Input type: select */
    grid_row_span: "row-span-1" | "row-span-2" | "row-span-3" | "row-span-4" | "row-span-5" | "row-span-6";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
    /** Input type: checkbox */
    image__drop_shadow: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: color_background */
    image__background?: string;
  };
  type: "image";
};

export type ProductDrawerBlocksText = {
  id: string;
  settings: {
    /** Input type: richtext */
    text?: `<p${string}</p>`;
  };
  type: "text";
};

export type ProductDrawerBlocksTitle = {
  id: string;
  settings: {
    /** Input type: range */
    font_scale: number;
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "title";
};

export type ProductDrawerBlocksVendor = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "vendor";
};

export type ProductDrawerBlocksPrice = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "price";
};

export type ProductDrawerBlocksVariant_selector = {
  id: string;
  settings: {
    /** Input type: checkbox */
    color_selector: boolean;
    /** Input type: radio */
    default_type: "radio" | "select";
    /** Input type: checkbox */
    disable_unavailable: boolean;
    /** Input type: checkbox */
    image_selector: boolean;
    /** Input type: textarea */
    color_list?: string;
  };
  type: "variant_selector";
};

export type ProductDrawerBlocksSku = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "sku";
};

export type ProductDrawerBlocksQuantity_selector = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "quantity_selector";
};

export type ProductDrawerBlocksBuy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "buy_buttons";
};

export type ProductDrawerBlocksDynamic_buy_buttons = {
  id: string;
  settings: {
    /** Input type: radio */
    button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "dynamic_buy_buttons";
};

export type ProductDrawerBlocksDescription = {
  id: string;
  settings: {
    /** Input type: checkbox */
    accordion_style: boolean;
  };
  type: "description";
};

export type ProductDrawerBlocksShare = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "share";
};

export type ProductDrawerBlocksCustom_liquid = {
  id: string;
  settings: {
    /** Input type: liquid */
    custom_liquid?: string;
  };
  type: "custom_liquid";
};

export type ProductDrawerBlocksCollapsible_tab = {
  id: string;
  settings: {
    /** Input type: select */
    icon: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: text */
    heading?: string;
    /** Input type: page */
    page?: _Page_liquid | string;
  };
  type: "collapsible_tab";
};

export type ProductDrawerBlocksRating = {
  id: string;
  settings: {
    /** Input type: select */
    grid_span: "col-span-3" | "col-span-4" | "col-span-6" | "col-span-8" | "col-span-9" | "col-span-12";
  };
  type: "rating";
};

export type ProductDrawerBlocksComplementary = {
  id: string;
  settings: {
    /** Input type: checkbox */
    image__show_secondary: boolean;
    /** Input type: product_list */
    products?: _Product_liquid[];
    /** Input type: text */
    title?: string;
  };
  type: "complementary";
};

export type ProductDrawerBlocksIcon_with_text = {
  id: string;
  settings: {
    /** Input type: select */
    icon_1: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_2: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    icon_3: "none" | "apple" | "banana" | "bottle" | "box" | "carrot" | "chat_bubble" | "check_mark" | "clipboard" | "dairy" | "dairy_free" | "dryer" | "eye" | "fire" | "gluten_free" | "heart" | "iron" | "leaf" | "leather" | "lightning_bolt" | "lipstick" | "lock" | "map_pin" | "nut_free" | "pants" | "paw_print" | "pepper" | "perfume" | "plane" | "plant" | "price_tag" | "question_mark" | "recycle" | "return" | "ruler" | "serving_dish" | "shirt" | "shoe" | "silhouette" | "snowflake" | "star" | "stopwatch" | "truck" | "washing";
    /** Input type: select */
    layout: "flex-row" | "flex-col";
    /** Input type: range */
    size: number;
    /** Input type: text */
    heading_1?: string;
    /** Input type: text */
    heading_2?: string;
    /** Input type: text */
    heading_3?: string;
    /** Input type: image_picker */
    image_1?: _Image_liquid | string;
    /** Input type: image_picker */
    image_2?: _Image_liquid | string;
    /** Input type: image_picker */
    image_3?: _Image_liquid | string;
  };
  type: "icon_with_text";
};

export type ProductDrawerBlocksInventory = {
  id: string;
  settings: {
    /** Input type: range */
    threshold: number;
  };
  type: "inventory";
};

export type ProductDrawerBlocks =
  | ProductDrawerBlocksImage
  | ProductDrawerBlocksText
  | ProductDrawerBlocksTitle
  | ProductDrawerBlocksVendor
  | ProductDrawerBlocksPrice
  | ProductDrawerBlocksVariant_selector
  | ProductDrawerBlocksSku
  | ProductDrawerBlocksQuantity_selector
  | ProductDrawerBlocksBuy_buttons
  | ProductDrawerBlocksDynamic_buy_buttons
  | ProductDrawerBlocksDescription
  | ProductDrawerBlocksShare
  | ProductDrawerBlocksCustom_liquid
  | ProductDrawerBlocksCollapsible_tab
  | ProductDrawerBlocksRating
  | ProductDrawerBlocksComplementary
  | ProductDrawerBlocksIcon_with_text
  | ProductDrawerBlocksInventory;

export type ProductSiblingsSection = {
  blocks: ProductSiblingsBlocks[];
  global: boolean;
  id: string;
  type: "product-sibling-groups";
};

export type ProductSiblingsBlocksSiblings = {
  id: string;
  settings: {
    /** Input type: textarea */
    options?: string;
    /** Input type: product_list */
    products?: _Product_liquid[];
    /** Input type: text */
    title?: string;
  };
  type: "siblings";
};

export type ProductSiblingsBlocks = ProductSiblingsBlocksSiblings;

export type ProductsScrollableSection = {
  blocks: ProductsScrollableBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    center_products: boolean;
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: checkbox */
    container_overflow: boolean;
    /** Input type: checkbox */
    hide_if_empty: boolean;
    /** Input type: checkbox */
    hide_out_of_stock: boolean;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: range */
    product_limit: number;
    /** Input type: select */
    product_source: "blocks" | "recently_viewed_products";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  };
  type: "products-scrollable";
};

export type ProductsScrollableBlocksHeading = {
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: range */
    preheading_font: number;
    /** Input type: range */
    subtitle_font: number;
    /** Input type: range */
    title_font: number;
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: text */
    preheading?: string;
    /** Input type: textarea */
    subtitle?: string;
    /** Input type: text */
    title?: string;
  };
  type: "heading";
};

export type ProductsScrollableBlocksView_all_bar = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: range */
    title_font: number;
    /** Input type: text */
    title?: string;
    /** Input type: url */
    url?: string;
  };
  type: "view_all_bar";
};

export type ProductsScrollableBlocksSource_products = {
  id: string;
  settings: {
    /** Input type: product_list */
    source?: _Product_liquid[];
  };
  type: "source_products";
};

export type ProductsScrollableBlocksSource_collection = {
  id: string;
  settings: {
    /** Input type: collection */
    source?: _Collection_liquid | string;
  };
  type: "source_collection";
};

export type ProductsScrollableBlocksSource_metafield = {
  id: string;
  settings: {
    /** Input type: text */
    source?: string;
  };
  type: "source_metafield";
};

export type ProductsScrollableBlocks =
  | ProductsScrollableBlocksHeading
  | ProductsScrollableBlocksView_all_bar
  | ProductsScrollableBlocksSource_products
  | ProductsScrollableBlocksSource_collection
  | ProductsScrollableBlocksSource_metafield;

export type RichtextSection = {
  blocks: RichtextBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: select */
    width: "max-w-full" | "max-w-[var(--layout-page-width)]" | "max-w-3xl" | "max-w-2xl" | "max-w-xl" | "max-w-lg" | "max-w-md" | "max-w-sm";
  };
  type: "richtext";
};

export type RichtextBlocksText = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type RichtextBlocksImage = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: image_picker */
    image?: _Image_liquid | string;
  };
  type: "image";
};

export type RichtextBlocksAccent_line = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    width: number;
    /** Input type: color */
    color?: _Color_liquid | string;
  };
  type: "accent_line";
};

export type RichtextBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type RichtextBlocks =
  | RichtextBlocksText
  | RichtextBlocksImage
  | RichtextBlocksAccent_line
  | RichtextBlocksButtons;

export type ScrollableImagesSection = {
  blocks: ScrollableImagesBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    min_width_desktop: number;
    /** Input type: range */
    min_width_mobile: number;
    /** Input type: select */
    padding_bottom: "pb-0" | "pb-sm" | "pb-md" | "pb-lg";
    /** Input type: select */
    padding_top: "pt-0" | "pt-sm" | "pt-md" | "pt-lg";
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: collection_list */
    collections?: _Collection_liquid[];
    /** Input type: color_background */
    overlay?: string;
    /** Input type: product_list */
    products?: _Product_liquid[];
  };
  type: "scrollable-images";
};

export type ScrollableImagesBlocksScrollbar_position = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
  };
  type: "scrollbar_position";
};

export type ScrollableImagesBlocksScrollable_image = {
  id: string;
  settings: {
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    title?: string;
    /** Input type: url */
    url?: string;
  };
  type: "scrollable_image";
};

export type ScrollableImagesBlocksText = {
  id: string;
  settings: {
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    title_type: number;
    /** Input type: richtext */
    title?: `<p${string}</p>`;
  };
  type: "text";
};

export type ScrollableImagesBlocksButtons = {
  id: string;
  settings: {
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
  };
  type: "buttons";
};

export type ScrollableImagesBlocksAccent_line = {
  id: string;
  settings: {
    /** Input type: range */
    height: number;
    /** Input type: range */
    margin_bottom: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: range */
    width: number;
    /** Input type: color */
    color?: _Color_liquid | string;
  };
  type: "accent_line";
};

export type ScrollableImagesBlocks =
  | ScrollableImagesBlocksScrollbar_position
  | ScrollableImagesBlocksScrollable_image
  | ScrollableImagesBlocksText
  | ScrollableImagesBlocksButtons
  | ScrollableImagesBlocksAccent_line;

export type SearchSection = {
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    article_show_author: boolean;
    /** Input type: checkbox */
    article_show_date: boolean;
    /** Input type: select */
    columns__desktop: "lg:grid-cols-1" | "lg:grid-cols-2" | "lg:grid-cols-3" | "lg:grid-cols-4" | "lg:grid-cols-5";
    /** Input type: select */
    columns__mobile: "grid-cols-1" | "grid-cols-2";
    /** Input type: checkbox */
    image__drop_shadow: boolean;
    /** Input type: select */
    image__ratio: "pb-[125%]" | "pb-[100%]";
    /** Input type: checkbox */
    image__show_secondary: boolean;
    /** Input type: radio */
    labels__discount: "sale" | "percentage" | "value";
    /** Input type: checkbox */
    labels__show: boolean;
    /** Input type: checkbox */
    rating__show: boolean;
    /** Input type: range */
    search_count: number;
    /** Input type: checkbox */
    show: boolean;
    /** Input type: checkbox */
    vendor__show: boolean;
    /** Input type: color_background */
    image__background?: string;
  };
  type: "search";
};

export type SlideshowSection = {
  blocks: SlideshowBlocks[];
  global: boolean;
  id: string;
  settings: {
    /** Input type: checkbox */
    auto_rotate: boolean;
    /** Input type: checkbox */
    fullscreen: boolean;
    /** Input type: range */
    height: number;
    /** Input type: range */
    slide_speed: number;
  };
  type: "slideshow";
};

export type SlideshowBlocksSlide = {
  id: string;
  settings: {
    /** Input type: radio */
    align__horizontal: "items-start text-left" | "items-center text-center" | "items-end text-right";
    /** Input type: radio */
    align__vertical: "justify-start" | "justify-center" | "justify-end";
    /** Input type: radio */
    button_primary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: radio */
    button_secondary__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
    /** Input type: select */
    color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
    /** Input type: range */
    preheading_font: number;
    /** Input type: radio */
    responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
    /** Input type: checkbox */
    slide: boolean;
    /** Input type: range */
    slide_speed: number;
    /** Input type: range */
    subtitle_font: number;
    /** Input type: range */
    title_font: number;
    /** Input type: text */
    button_primary__text?: string;
    /** Input type: url */
    button_primary__url?: string;
    /** Input type: text */
    button_secondary__text?: string;
    /** Input type: url */
    button_secondary__url?: string;
    /** Input type: richtext */
    content?: `<p${string}</p>`;
    /** Input type: image_picker */
    image?: _Image_liquid | string;
    /** Input type: color_background */
    image__overlay?: string;
    /** Input type: text */
    preheading?: string;
    /** Input type: textarea */
    subtitle?: string;
    /** Input type: text */
    title?: string;
  };
  type: "slide";
};

export type SlideshowBlocks = SlideshowBlocksSlide;

export type Sections =
  | AppsSection
  | BenefitTabsSection
  | CartDrawerSection
  | CollectionNavSection
  | CustomLiquidSection
  | CustomProductAndrewsSection
  | FaqSection
  | FeaturedCollectionGridSection
  | FeaturesSection
  | FooterSection
  | FormsSection
  | HeaderSection
  | ImageBannerSection
  | ImageFeedSection
  | ImageWithTextSection
  | MainAccountSection
  | MainAddressesSection
  | MainArticleSection
  | MainBlogSection
  | MainCartSection
  | MainCollectionBannerSection
  | MainCollectionFilterSortBarSection
  | MainCollectionProductGridSection
  | MainCollectionsListSection
  | MainOrderSection
  | MainPageSection
  | MainSearchFiltersSection
  | MainSearchGridSection
  | MainSearchInputSection
  | Main404Section
  | MarqueeBarSection
  | NewsletterSection
  | ObjectOverImageSection
  | PasswordFooterSection
  | PasswordHeaderSection
  | PredictiveSearchSection
  | ProductSection
  | ProductAddToCartBarSection
  | ProductDataSection
  | ProductDrawerSection
  | ProductSiblingsSection
  | ProductsScrollableSection
  | RichtextSection
  | ScrollableImagesSection
  | SearchSection
  | SlideshowSection;
