import { _Image_liquid, _Color_liquid, _Font_liquid, _Font_options } from "./shopify";

export type SettingsSchema = {
  /** Input type: range */
  button_border_radius: number;
  /** Input type: range */
  button_border_width: number;
  /** Input type: range */
  button_horizontal_padding: number;
  /** Input type: range */
  button_hover_border_radius: number;
  /** Input type: range */
  button_hover_scale: number;
  /** Input type: range */
  button_hover_shadow: number;
  /** Input type: range */
  button_shadow: number;
  /** Input type: select */
  button_text_transform: "none" | "uppercase" | "lowercase" | "capitalize";
  /** Input type: range */
  button_vertical_padding: number;
  /** Input type: select */
  cart_color_scheme: "bg-theme-bg text-theme-text color-inherit" | "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
  /** Input type: checkbox */
  cart_gift_checkbox: boolean;
  /** Input type: checkbox */
  cart_note: boolean;
  /** Input type: select */
  cart_type: "drawer" | "page";
  /** Input type: select */
  color_grayscale: "slate" | "gray" | "zinc" | "neutral" | "stone";
  /** Input type: radio */
  color_grayscale_style: "normal" | "inverted";
  /** Input type: select */
  color_scheme: "bg-theme-bg text-theme-text color-group-1" | "bg-theme-bg text-theme-text color-group-2" | "bg-theme-bg text-theme-text color-group-3";
  /** Input type: checkbox */
  currency_code_enabled: boolean;
  /** Input type: radio */
  design_border_radius: "soft" | "medium" | "bold";
  /** Input type: radio */
  design_pagination_style: "compact" | "floating";
  /** Input type: font_picker */
  font_body: _Font_liquid | _Font_options;
  /** Input type: range */
  font_body_letter_spacing: number;
  /** Input type: range */
  font_body_line_height: number;
  /** Input type: range */
  font_body_mobile_size: number;
  /** Input type: range */
  font_body_size: number;
  /** Input type: select */
  font_body_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_body_weight: number;
  /** Input type: font_picker */
  font_button: _Font_liquid | _Font_options;
  /** Input type: range */
  font_button_letter_spacing: number;
  /** Input type: range */
  font_button_mobile_size: number;
  /** Input type: range */
  font_button_size: number;
  /** Input type: range */
  font_button_weight: number;
  /** Input type: font_picker */
  font_heading_1: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_1_letter_spacing: number;
  /** Input type: range */
  font_heading_1_line_height: number;
  /** Input type: range */
  font_heading_1_mobile_size: number;
  /** Input type: range */
  font_heading_1_size: number;
  /** Input type: select */
  font_heading_1_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_1_weight: number;
  /** Input type: font_picker */
  font_heading_2: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_2_letter_spacing: number;
  /** Input type: range */
  font_heading_2_line_height: number;
  /** Input type: range */
  font_heading_2_mobile_size: number;
  /** Input type: range */
  font_heading_2_size: number;
  /** Input type: select */
  font_heading_2_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_2_weight: number;
  /** Input type: font_picker */
  font_heading_3: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_3_letter_spacing: number;
  /** Input type: range */
  font_heading_3_line_height: number;
  /** Input type: range */
  font_heading_3_mobile_size: number;
  /** Input type: range */
  font_heading_3_size: number;
  /** Input type: select */
  font_heading_3_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_3_weight: number;
  /** Input type: font_picker */
  font_heading_4: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_4_letter_spacing: number;
  /** Input type: range */
  font_heading_4_line_height: number;
  /** Input type: range */
  font_heading_4_mobile_size: number;
  /** Input type: range */
  font_heading_4_size: number;
  /** Input type: select */
  font_heading_4_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_4_weight: number;
  /** Input type: font_picker */
  font_heading_5: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_5_letter_spacing: number;
  /** Input type: range */
  font_heading_5_line_height: number;
  /** Input type: range */
  font_heading_5_mobile_size: number;
  /** Input type: range */
  font_heading_5_size: number;
  /** Input type: select */
  font_heading_5_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_5_weight: number;
  /** Input type: font_picker */
  font_heading_6: _Font_liquid | _Font_options;
  /** Input type: range */
  font_heading_6_letter_spacing: number;
  /** Input type: range */
  font_heading_6_line_height: number;
  /** Input type: range */
  font_heading_6_mobile_size: number;
  /** Input type: range */
  font_heading_6_size: number;
  /** Input type: select */
  font_heading_6_tag: "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "blockquote" | "div";
  /** Input type: range */
  font_heading_6_weight: number;
  /** Input type: checkbox */
  layout_is_fullwidth: boolean;
  /** Input type: range */
  layout_page_width: number;
  /** Input type: range */
  layout_section_padding_lg: number;
  /** Input type: range */
  layout_section_padding_md: number;
  /** Input type: range */
  layout_section_padding_sm: number;
  /** Input type: checkbox */
  predictive_search_enabled: boolean;
  /** Input type: checkbox */
  predictive_search_show_price: boolean;
  /** Input type: checkbox */
  predictive_search_show_vendor: boolean;
  /** Input type: radio */
  product_card__button__style: "button-primary" | "button-primary--outline" | "button-secondary" | "button-secondary--outline";
  /** Input type: checkbox */
  product_card__image__drop_shadow: boolean;
  /** Input type: range */
  product_card__image__margin_bottom: number;
  /** Input type: select */
  product_card__image__ratio: "pb-[100%]" | "pb-[125%]" | "pb-[133%]" | "pb-[177%]";
  /** Input type: checkbox */
  product_card__image__show_secondary: boolean;
  /** Input type: radio */
  product_card__labels__discount: "sale" | "percentage" | "value";
  /** Input type: radio */
  product_card__labels__responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  /** Input type: checkbox */
  product_card__labels__show: boolean;
  /** Input type: range */
  product_card__price__margin_bottom: number;
  /** Input type: radio */
  product_card__price__responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  /** Input type: checkbox */
  product_card__price__show: boolean;
  /** Input type: range */
  product_card__rating__margin_bottom: number;
  /** Input type: radio */
  product_card__rating__responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  /** Input type: checkbox */
  product_card__rating__show: boolean;
  /** Input type: range */
  product_card__title__margin_bottom: number;
  /** Input type: range */
  product_card__title__type: number;
  /** Input type: radio */
  product_card__variant_count__responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  /** Input type: checkbox */
  product_card__variant_count__show: boolean;
  /** Input type: checkbox */
  product_card__variant_selector__show: boolean;
  /** Input type: range */
  product_card__vendor__margin_bottom: number;
  /** Input type: radio */
  product_card__vendor__responsive_visibility: "responsive" | "md:hidden" | "max-md:hidden";
  /** Input type: checkbox */
  product_card__vendor__show: boolean;
  /** Input type: image_picker */
  branding_favicon?: _Image_liquid | string;
  /** Input type: image_picker */
  branding_logo_dark_on_light?: _Image_liquid | string;
  /** Input type: image_picker */
  branding_logo_light_on_dark?: _Image_liquid | string;
  /** Input type: color */
  color_1_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_1_bg_gradient?: string;
  /** Input type: color */
  color_1_overlay_text?: _Color_liquid | string;
  /** Input type: color */
  color_1_primary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_1_primary_bg_gradient?: string;
  /** Input type: color */
  color_1_primary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_1_primary_text?: _Color_liquid | string;
  /** Input type: color */
  color_1_secondary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_1_secondary_bg_gradient?: string;
  /** Input type: color */
  color_1_secondary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_1_secondary_text?: _Color_liquid | string;
  /** Input type: color */
  color_1_text?: _Color_liquid | string;
  /** Input type: text */
  color_1_title?: string;
  /** Input type: color */
  color_2_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_2_bg_gradient?: string;
  /** Input type: color */
  color_2_overlay_text?: _Color_liquid | string;
  /** Input type: color */
  color_2_primary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_2_primary_bg_gradient?: string;
  /** Input type: color */
  color_2_primary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_2_primary_text?: _Color_liquid | string;
  /** Input type: color */
  color_2_secondary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_2_secondary_bg_gradient?: string;
  /** Input type: color */
  color_2_secondary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_2_secondary_text?: _Color_liquid | string;
  /** Input type: color */
  color_2_text?: _Color_liquid | string;
  /** Input type: text */
  color_2_title?: string;
  /** Input type: color */
  color_3_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_3_bg_gradient?: string;
  /** Input type: color */
  color_3_overlay_text?: _Color_liquid | string;
  /** Input type: color */
  color_3_primary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_3_primary_bg_gradient?: string;
  /** Input type: color */
  color_3_primary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_3_primary_text?: _Color_liquid | string;
  /** Input type: color */
  color_3_secondary_bg?: _Color_liquid | string;
  /** Input type: color_background */
  color_3_secondary_bg_gradient?: string;
  /** Input type: color */
  color_3_secondary_outline?: _Color_liquid | string;
  /** Input type: color */
  color_3_secondary_text?: _Color_liquid | string;
  /** Input type: color */
  color_3_text?: _Color_liquid | string;
  /** Input type: text */
  color_3_title?: string;
  /** Input type: color */
  color_error?: _Color_liquid | string;
  /** Input type: color */
  color_info?: _Color_liquid | string;
  /** Input type: color */
  color_review_stars?: _Color_liquid | string;
  /** Input type: color */
  color_success?: _Color_liquid | string;
  /** Input type: color */
  color_warning?: _Color_liquid | string;
  /** Input type: text */
  font_body_custom?: string;
  /** Input type: text */
  font_button_custom?: string;
  /** Input type: text */
  font_heading_1_custom?: string;
  /** Input type: text */
  font_heading_2_custom?: string;
  /** Input type: text */
  font_heading_3_custom?: string;
  /** Input type: text */
  font_heading_4_custom?: string;
  /** Input type: text */
  font_heading_5_custom?: string;
  /** Input type: text */
  font_heading_6_custom?: string;
  /** Input type: color */
  product_card__background_color?: _Color_liquid | string;
  /** Input type: color_background */
  product_card__image__background?: string;
  /** Input type: textarea */
  product_card__variant_selector__color_list?: string;
  /** Input type: text */
  social_facebook_link?: string;
  /** Input type: text */
  social_instagram_link?: string;
  /** Input type: text */
  social_pinterest_link?: string;
  /** Input type: text */
  social_snapchat_link?: string;
  /** Input type: text */
  social_tiktok_link?: string;
  /** Input type: text */
  social_tumblr_link?: string;
  /** Input type: text */
  social_twitter_link?: string;
  /** Input type: text */
  social_vimeo_link?: string;
  /** Input type: text */
  social_youtube_link?: string;
};
