import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { BenefitTabsSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const benefitTabs: ShopifySection<BenefitTabsSection> = {
  name: "Benefit tabs",
  settings: [
    {
      type: "radio",
      id: "layout",
      label: "Desktop Layout",
      default: "order-2",
      options: [
        {
          value: "order-2",
          label: "Image Left",
        },
        {
          value: "-order-1",
          label: "Image Right",
        },
      ],
    },
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.colorScheme,
  ],
  max_blocks: 3,
  blocks: [
    {
      type: "benefit",
      name: "Benefit",
      settings: [
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "title",
          label: "Title",
          default: "phasellus vocibus sem metus postulant",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 4 }),
        {
          type: "richtext",
          id: "content",
          label: "Richtext",
          default: "<p>See you later, Pop. Whoo! Time to change that oil.</p>",
        },
      ],
    },
  ],

  presets: [
    {
      name: "Benefit tabs",
      blocks: [{ type: "benefit" }, { type: "benefit" }, { type: "benefit" }],
    },
  ],
};
