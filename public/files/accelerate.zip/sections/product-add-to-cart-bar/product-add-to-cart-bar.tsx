import { useGlobalProducts, useLineItems } from "globals/utils/global-stores";
import { Image } from "globals/utils/image";
import { scrollToY } from "globals/utils/utils";
import { FC, useCallback } from "react";
import { useMemo } from "react";
import { useProductDrawer } from "sections/product-drawer/product-drawer";
import { ReactProductState } from "sections/product/product";
import { ProductBuyButtons } from "sections/product/product.buy_buttons";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductAddToCartBar: FC<{
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
  upsellProductId: string | number;
}> = ({ useProduct, upsellProductId }) => {
  const { selectedVariant, product } = useProduct();
  const { getProduct } = useGlobalProducts();
  const { cartData } = useLineItems();
  const { updateProduct } = useProductDrawer(({ updateProduct }) => ({ updateProduct }));

  const handleClick = useCallback((e) => {
    const productElement = document.querySelector<HTMLElement>(`[data-product-id="${product.id}"]`);
    const headerElement = document.querySelector<HTMLElement>(`.header-position`);
    if (productElement) {
      scrollToY(500, productElement.offsetTop - headerElement.clientHeight);
    }
  }, [product.id]);

  const upsellProduct = getProduct(upsellProductId);

  const handleUpsellProductClick = useCallback(() => {
    updateProduct(upsellProduct);
    setTimeout(() => document.dispatchEvent(new Event("product:open")), 1);
  }, [updateProduct, upsellProduct]);

  if (cartData.items.some((item) => item.variant_id === selectedVariant.id)) {
    if (!upsellProduct) {
      return <></>;
    }

    return (
      <>
        <picture className="relative block aspect-1 h-full overflow-hidden rounded-theme-sm border border-theme-text/60">
          <Image
            src={
              upsellProduct.selected_or_first_available_variant?.featured_media?.src ??
              upsellProduct.featured_media?.src
            }
            alt={upsellProduct.title}
            width={80}
            className="inset-0 block h-full w-full object-cover object-center"
          />
        </picture>
        <a
          className="flex flex flex-col justify-center whitespace-nowrap"
          href={upsellProduct.url.split("?")?.[0]}
        >
          <span className="max-w-[100px] truncate text-sm font-semibold tracking-tight sm:max-w-[300px]">
            {upsellProduct.title}
          </span>
          <span className="max-w-[100px] truncate text-xs tracking-tight sm:max-w-[300px]">
            {upsellProduct.selected_or_first_available_variant?.title}
          </span>
        </a>

        <button type="button" className="button-primary" onClick={handleUpsellProductClick}>
          View More
        </button>
      </>
    );
  }

  return (
    <>
      <picture className="relative block aspect-1 h-full overflow-hidden rounded-theme-sm border border-theme-text/60">
        <Image
          src={selectedVariant.featured_media.src ?? product.featured_media?.preview_image?.src}
          alt={selectedVariant.featured_media.alt ?? product.title}
          width={80}
          className="inset-0 block h-full w-full object-cover object-center"
        />
      </picture>
      <button
        className="flex flex flex-col justify-center whitespace-nowrap"
        type="button"
        onClick={handleClick}
      >
        <span className="max-w-[100px] truncate text-sm font-semibold tracking-tight sm:max-w-[300px]">
          {product.title}
        </span>
        <span className="max-w-[100px] truncate text-xs tracking-tight sm:max-w-[300px]">
          {selectedVariant.title}
        </span>
      </button>
      <ProductBuyButtons useProduct={useProduct} />
    </>
  );
};
