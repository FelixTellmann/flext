import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { ProductAddToCartBarSection } from "types/sections";

export const productAddToCartBar: ShopifySection<ProductAddToCartBarSection> = {
  name: "Add to cart bar",
  settings: [
    {
      type: "product",
      id: "upsell_product",
      label: "Upsell product",
      info: "Setup via Metafields App as Default",
    },
    sectionGlobals.responsiveVisibility,
    sectionGlobals.colorScheme,
  ],
  max_blocks: 3,
  blocks: [
    {
      type: "link",
      name: "Link",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
      ],
    },
  ],
  presets: [
    {
      name: "Product add to cart bar",
    },
  ],
};
