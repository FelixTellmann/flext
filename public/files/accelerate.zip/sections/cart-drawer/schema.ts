import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { CartDrawerSection } from "types/sections";

export const cartDrawer: ShopifySection<CartDrawerSection> = {
  name: "Header & Cart Promotions",
  disabled_block_files: true,
  settings: [
    {
      type: "header",
      content: "Free Shipping Bar",
    },
    {
      type: "radio",
      id: "free_shipping_bar__show",
      label: "Show",
      default: "all",
      options: [
        {
          value: "all",
          label: "Header & Cart",
        },
        {
          value: "header",
          label: "Header Only",
        },
        {
          value: "cart",
          label: "Cart Only",
        },
        {
          value: "disable",
          label: "Disable",
        },
      ],
    },
    {
      type: "radio",
      id: "free_shipping_bar__type",
      label: "Base free shipping on",
      default: "item_count",
      options: [
        {
          value: "item_count",
          label: "Cart item quantity",
        },
        {
          value: "total_price",
          label: "Cart total price",
        },
      ],
    },
    {
      type: "range",
      id: "free_shipping_bar__starting_percentage",
      label: "Starting point",
      default: 0,
      min: 0,
      max: 50,
      step: 1,
      unit: "%",
    },
    {
      type: "number",
      id: "free_shipping_bar__target",
      label: "Target",
      info: "In Cents for `Cart Total` calculation (i.e. $39,40 -> 3940)",
      default: 3,
    },
    {
      type: "range",
      id: "free_shipping_bar__height",
      label: "Height",
      default: 40,
      min: 28,
      max: 100,
      step: 1,
      unit: "px",
    },
    {
      ...sectionGlobals.colorScheme,
      id: "free_shipping_bar__color_scheme",
    },
    {
      type: "header",
      content: "Announcement",
    },
    {
      type: "radio",
      id: "announcements__show",
      label: "Show",
      default: "all",
      options: [
        {
          value: "all",
          label: "Header & Cart",
        },
        {
          value: "header",
          label: "Header Only",
        },
        {
          value: "cart",
          label: "Cart Only",
        },
        {
          value: "disable",
          label: "Disable",
        },
      ],
    },
    {
      type: "range",
      id: "announcements__height",
      label: "Height",
      default: 40,
      min: 28,
      max: 100,
      step: 1,
      unit: "px",
    },
    {
      type: "header",
      content: "Cart Drawer",
    },
    {
      type: "checkbox",
      id: "cart__recommended_products__enable",
      label: "Enable recommended products",
      default: true,
    },
    {
      type: "product_list",
      id: "cart__recommended_products",
      label: "Recommended Products",
    },
  ],
  blocks: [
    {
      type: "announcement",
      name: "Announcement",
      limit: 6,
      settings: [
        {
          type: "header",
          content: "Content",
        },
        {
          type: "richtext",
          id: "text",
          label: "Text",
        },
        {
          type: "richtext",
          id: "short_text",
          label: "Shorter Text",
          info: "Change this if you need a shorter text on smaller devices.",
        },
        {
          type: "url",
          id: "link",
          label: "Link",
        },
        {
          type: "header",
          content: "Colors",
        },
        {
          type: "color",
          id: "color_bg",
          label: "Background",
        },
        {
          type: "color",
          id: "color_text",
          label: "Text",
        },
        {
          type: "header",
          content: "Settings",
        },
        {
          type: "select",
          id: "position",
          label: "Content Position",
          default: "center",
          options: [
            {
              value: "left",
              label: "Left",
            },
            {
              value: "center",
              label: "Center",
            },
            {
              value: "right",
              label: "Right",
            },
          ],
        },
        {
          type: "range",
          id: "display_duration",
          label: "Display duration",
          info: "Only applicable if multiple announcements are active.",
          default: 10,
          min: 5,
          max: 60,
          step: 1,
          unit: "s",
        },
        {
          type: "header",
          content: "Scheduling",
        },
        {
          type: "checkbox",
          id: "scheduled",
          label: "Activate Scheduling",
          info: "Requires at least a Start or End Date",
        },
        {
          type: "text",
          id: "start_date",
          label: "Start Date",
          info: "Use Date format yyyy/mm/dd hh:mm:ss",
          placeholder: "2021/06/01 00:00:00",
        },
        {
          type: "text",
          id: "end_date",
          label: "End Date",
          info: "Use Date format yyyy/mm/dd hh:mm:ss",
          placeholder: "2022/07/31 23.59:00",
        },
      ],
    },
  ],
};
