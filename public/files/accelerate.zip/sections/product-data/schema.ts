import { ShopifySection } from "types/shopify";
import { ProductDataSection } from "types/sections";

export const productData: ShopifySection<ProductDataSection> = {
  name: "Product data",
  enabled_on: {
    templates: ["product"],
  },
};
