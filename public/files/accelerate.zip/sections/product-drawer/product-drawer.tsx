import { useGlobalProducts } from "globals/utils/global-stores";
import { JSONParse } from "globals/utils/utils";
import { render } from "preact";
import { FC, useCallback, useEffect, useRef } from "react";
import { initProductStore, ReactProductState } from "sections/product/product";
import { ProductBuyButtons } from "sections/product/product.buy_buttons";
import { ProductComplementaryItems } from "sections/product/product.complementary";
import { ProductDescription } from "sections/product/product.description";
import { ProductGalleryHorizontal, ProductGalleryVertical } from "sections/product/product.gallery";
import { ProductImage } from "sections/product/product.image";
import { ProductInventorySlider } from "sections/product/product.inventory";
import { ProductPreOrder } from "sections/product/product.pre_order";
import { ProductPrice } from "sections/product/product.price";
import { ProductQuantitySelector } from "sections/product/product.quantity_selector";
import { ProductRating } from "sections/product/product.rating";
import { ProductShare } from "sections/product/product.share";
import { ProductSideEffects } from "sections/product/product.side-effects";
import { ProductSku } from "sections/product/product.sku";
import { ProductTitle } from "sections/product/product.title";
import { ProductVariantSelector } from "sections/product/product.variant_selector";
import { ProductVendor } from "sections/product/product.vendor";
import { ProductBlocks, ProductBlocksBuy_buttons, ProductBlocksComplementary, ProductBlocksDescription, ProductBlocksImage, ProductBlocksInventory, ProductBlocksPre_order, ProductBlocksVariant_selector, ProductDrawerSection, ProductSection } from "types/sections";
import { create, StoreApi, UseBoundStore } from "zustand";

const productSection = document.querySelector<HTMLElement>("[data-product-drawer-product-id]");
const productId = productSection?.dataset?.productDrawerProductId ?? "";
const formId = productSection?.dataset?.productDrawerFormId ?? "";

export const useProductDrawer = create(initProductStore(productSection, productId, formId));

if (productSection) {
  initProductDrawer();
}

function ProductDrawerPreloadEvents({
  useProduct,
}: {
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}) {
  const { preloadProduct, getProduct, hydrated } = useGlobalProducts(
    ({ preloadProduct, getProduct, hydrated }) => ({
      preloadProduct,
      getProduct,
      hydrated,
    })
  );

  const productImagesLoaded = useRef([]);
  const updateProduct = useProduct((state) => state?.updateProduct);

  useEffect(() => {
    if (hydrated) {
      document.querySelectorAll<HTMLElement>("[data-drawer-product]").forEach((productElement) => {
        const productId = productElement.dataset.drawerProduct;
        const productUrl = productElement.dataset.drawerProductUrl;
        const button = productElement.querySelector<HTMLButtonElement>(
          "[data-product-drawer-add-button]"
        );

        if (!button || button?.disabled) return;

        if ("IntersectionObserver" in window) {
          const observer = new IntersectionObserver(async (entries, observer) => {
            for (let i = 0; i < entries.length; i++) {
              const entry = entries[i];
              if (!entry.isIntersecting) return;
              observer.unobserve(entry.target);

              const product = await preloadProduct(productId, productUrl);

              const withImage = product?.featured_media?.src;
              if (withImage && !productImagesLoaded.current.includes(productId)) {
                productImagesLoaded.current.push(productId);

                const image = document.createElement("img");
                image.src = `${product?.featured_media?.src}&width=180`;
              }
            }
          });
          observer.observe(productElement);
        }
      });
    }
  }, [hydrated, preloadProduct]);

  const handleClick = useCallback((e) => {
    const productId = e.target.closest("[data-product-drawer-add-button]")?.dataset
      ?.productDrawerAddButton;
    e.preventDefault();
    updateProduct(getProduct(productId));
    // document.dispatchEvent(new Event("product:open"));
    setTimeout(() => document.dispatchEvent(new Event("product:open")), 1);
  }, [getProduct, updateProduct]);

  useEffect(() => {
    document
      .querySelectorAll<HTMLElement>("[data-product-drawer-add-button]")
      .forEach((productDrawerButton) => {
        productDrawerButton.addEventListener("click", handleClick);
      });

    return () => {
      document
        .querySelectorAll<HTMLElement>("[data-product-drawer-add-button]")
        .forEach((productDrawerButton) => {
          productDrawerButton.removeEventListener("click", handleClick);
        });
    };
  }, [handleClick]);

  useEffect(() => {
    const MutationObserver = window.MutationObserver || window["WebKitMutationObserver"];

    // define a new observer
    const mutationObserver = new MutationObserver((e) => {
      e?.forEach((record) =>
        record.addedNodes.forEach(async (node) => {
          if (node?.dataset?.drawerProduct) {
            const productElement = node as HTMLElement;

            const productId = productElement.dataset.drawerProduct;
            const productUrl = productElement.dataset.drawerProductUrl;
            const button = productElement.querySelector<HTMLButtonElement>(
              "[data-product-drawer-add-button]"
            );

            if (!button || button?.disabled) return;

            const product = await preloadProduct(productId, productUrl);

            const withImage = product?.featured_media?.src;
            if (withImage && !productImagesLoaded.current.includes(productId)) {
              productImagesLoaded.current.push(productId);

              const image = document.createElement("img");
              image.src = `${product?.featured_media?.src}&width=180`;
            }

            button.addEventListener("click", handleClick);
          }
        })
      );
    });

    if (hydrated) {
      // have the observer observe foo for changes in children
      mutationObserver.observe(document.body, { childList: true, subtree: true });
    }
    return () => {
      mutationObserver.disconnect();
    };
  }, [handleClick, hydrated, preloadProduct]);

  return null;
}

function initProductDrawer() {
  productSection.querySelectorAll<HTMLElement>(`[data-product-block]`).forEach((block) => {
    const type = block.dataset.productBlock as
      | ProductBlocks["type"]
      | "side_effects"
      | "preload_products";
    // console.log({ type, settings: block.dataset.blockSettings });
    const settings = block.dataset.blockSettings ? JSONParse(block.dataset.blockSettings) : null;

    switch (type) {
      case "@app":
        return;
      case "text":
        return;
      case "title":
        render(<ProductTitle useProduct={useProductDrawer} />, block);
        return;
      case "vendor":
        render(<ProductVendor useProduct={useProductDrawer} />, block);
        return;
      case "description":
        render(
          <ProductDescription
            settings={settings as ProductBlocksDescription["settings"]}
            useProduct={useProductDrawer}
          />,
          block
        );
        return;
      case "share":
        render(<ProductShare useProduct={useProductDrawer} />, block);
        return;
      case "custom_liquid":
        return;
      case "collapsible_tab":
        return;
      case "rating":
        render(<ProductRating useProduct={useProductDrawer} />, block);
        return;
      case "complementary":
        render(
          <ProductComplementaryItems
            settings={settings as ProductBlocksComplementary["settings"]}
            useProduct={useProductDrawer}
          />,
          block
        );
        return;
      case "icon_with_text":
        return;
      case "price": {
        block.innerHTML = "";
        render(<ProductPrice useProduct={useProductDrawer} />, block);
        return;
      }
      case "variant_selector": {
        block.innerHTML = "";
        render(
          <ProductVariantSelector
            useProduct={useProductDrawer}
            settings={settings as ProductBlocksVariant_selector["settings"]}
          />,
          block
        );
        return;
      }
      case "sku": {
        block.innerHTML = "";
        render(<ProductSku useProduct={useProductDrawer} />, block);
        return;
      }
      case "quantity_selector": {
        block.innerHTML = "";
        render(<ProductQuantitySelector useProduct={useProductDrawer} />, block);
        return;
      }
      case "buy_buttons": {
        block.innerHTML = "";
        render(
          <ProductBuyButtons
            useProduct={useProductDrawer}
            settings={settings as ProductBlocksBuy_buttons["settings"]}
          />,
          block
        );
        return;
      }
      case "dynamic_buy_buttons": {
        return;
      }
      case "inventory": {
        block.innerHTML = "";
        render(
          <ProductInventorySlider
            settings={settings as ProductBlocksInventory["settings"]}
            useProduct={useProductDrawer}
          />,
          block
        );
        return;
      }
      case "image": {
        render(
          <ProductImage
            settings={settings as ProductBlocksImage["settings"]}
            useProduct={useProductDrawer}
          />,
          block
        );
        return;
      }
      case "side_effects": {
        block.innerHTML = "";
        render(<ProductSideEffects useProduct={useProductDrawer} />, block);
        return;
      }
      case "preload_products": {
        block.innerHTML = "";
        render(<ProductDrawerPreloadEvents useProduct={useProductDrawer} />, block);
        return;
      }
      case "pre_order": {
        block.innerHTML = "";
        render(
          <ProductPreOrder
            settings={settings as ProductBlocksPre_order["settings"]}
            useProduct={useProductDrawer}
          />,
          block
        );
        return;
      }
    }
  });
}
