import { sectionGlobals } from "globals/settings/section-globals";
import { maxWidth } from "globals/settings/max-width";
import { FaqSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const faq: ShopifySection<FaqSection> = {
  name: "Faq",
  settings: [
    {
      type: "text",
      id: "title",
      label: "Title",
    },
    maxWidth,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "group",
      name: "Group",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Title",
        },
      ],
    },
    {
      type: "faq",
      name: "Question & Answer",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Question",
        },
        {
          type: "richtext",
          id: "answer",
          label: "Answer",
        },
        {
          type: "page",
          id: "page",
          label: "Page",
          info: "Uses the page Title as the question and the content as the answer",
        },
      ],
    },
  ],

  presets: [
    {
      name: "Faq",
    },
  ],
};
