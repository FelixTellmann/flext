import { MainOrderSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainOrder: ShopifySection<MainOrderSection> = {
  name: "Order",
  settings: [
    {
      type: "header",
      content: "Section padding",
    },
    {
      type: "range",
      id: "padding_top",
      min: 0,
      max: 100,
      step: 4,
      unit: "px",
      label: "Top padding",
      default: 36,
    },
    {
      type: "range",
      id: "padding_bottom",
      min: 0,
      max: 100,
      step: 4,
      unit: "px",
      label: "Bottom padding",
      default: 36,
    },
  ],
};
