import { contentBlocks } from "globals/settings/content-blocks";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { ShopifySection } from "types/shopify";
import { CollectionNavSection } from "types/sections";

export const collectionNav: ShopifySection<CollectionNavSection> = {
  name: "Collection nav",
  generate_block_files: ["tab_group"],
  enabled_on: {
    templates: ["collection"],
  },
  settings: [
    {
      type: "header",
      content: "Image",
    },
    {
      type: "paragraph",
      content:
        "The section uses the collection image as a default. Alternatively, you can setup the image via metafields. Metafield images take priority over collection images.",
    },
    {
      type: "text",
      id: "collection_image_metafield",
      label: "Metafield key",
      info: "You can setup metafields in your theme settings. Use the 'accelerate' namespace when setting up the Metafield. (I.e. 'accelerate.key')",
    },
    {
      type: "color_background",
      id: "overlay",
      label: "Overlay",
      default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "range",
      id: "min_width_desktop",
      label: "Min Width Desktop",
      default: 240,
      min: 80,
      max: 500,
      step: 10,
      unit: "px",
    },
    {
      type: "range",
      id: "min_width_mobile",
      label: "Min Width Mobile",
      default: 240,
      min: 80,
      max: 500,
      step: 10,
      unit: "px",
    },
    {
      id: "aspect_ratio",
      type: "select",
      default: "pb-[125%]",
      options: [
        {
          value: "pb-[100%]",
          label: "Square (1:1)",
        },
        {
          value: "pb-[125%]",
          label: "Portrait (4:5)",
        },
        {
          value: "pb-[133%]",
          label: "Tall Portrait (4:3)",
        },
        {
          value: "pb-[177%]",
          label: "Story (9:16)",
        },
      ],
      label: "Image ratio",
    },
    {
      type: "header",
      content: "Image Caption",
    },
    typeRange({ id: "title_type", label: "Typography", default_font: 6 }),
    {
      type: "header",
      content: "Layout",
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    contentBlocks.text,
    contentBlocks.accentLine,
    contentBlocks.buttonGroup,
    {
      type: "tab_group",
      name: "Tab Group",
      settings: [
        {
          type: "text",
          id: "tab",
          label: "Title",
        },
        {
          type: "collection_list",
          id: "collection_list",
          label: "Collections",
        },
        {
          type: "text",
          id: "collection_metafield",
          label: "Metafield key",
          default: "sibling_collections",
          info: "You can setup metafields in your theme settings. Use the 'accelerate' namespace when setting up the Metafield. (I.e. 'accelerate.key')",
        },
      ],
    },
  ],

  presets: [
    {
      name: "Collection nav",
    },
  ],
};
