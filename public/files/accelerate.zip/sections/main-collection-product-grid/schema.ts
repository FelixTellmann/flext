import { sectionGlobals } from "globals/settings/section-globals";
import { productCardSettings } from "globals/settings/product-card-settings";
import { MainCollectionProductGridSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainCollectionProductGrid: ShopifySection<MainCollectionProductGridSection> = {
  name: "Product grid",
  class: "section",
  settings: [
    {
      content: "Layout",
      type: "header",
    },
    {
      id: "pagination_size",
      type: "range",
      min: 8,
      max: 48,
      step: 4,
      default: 16,
      label: "Products per page",
    },
    {
      type: "select",
      id: "columns__desktop",
      default: "lg:grid-cols-4",
      label: "Number of columns on desktop",
      options: [
        {
          value: "lg:grid-cols-1",
          label: "1 column",
        },
        {
          value: "lg:grid-cols-2",
          label: "2 columns",
        },
        {
          value: "lg:grid-cols-3",
          label: "3 columns",
        },
        {
          value: "lg:grid-cols-4",
          label: "4 columns",
        },
        {
          value: "lg:grid-cols-5",
          label: "5 columns",
        },
      ],
    },
    {
      type: "select",
      id: "columns__mobile",
      default: "grid-cols-2",
      label: "Number of columns on mobile",
      options: [
        {
          value: "grid-cols-1",
          label: "1 column",
        },
        {
          value: "grid-cols-2",
          label: "2 columns",
        },
      ],
    },
    sectionGlobals.colorScheme,
  ],
};
