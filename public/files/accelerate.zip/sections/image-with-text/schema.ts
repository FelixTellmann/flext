import { buttons } from "globals/settings/buttons";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { ImageWithTextSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const imageWithText: ShopifySection<ImageWithTextSection> = {
  name: "Image with text",
  settings: [
    {
      type: "header",
      content: "Image",
    },
    {
      type: "image_picker",
      id: "image",
      label: "Image",
    },
    {
      type: "color_background",
      id: "image__overlay",
      label: "Overlay",
      default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "select",
      id: "image__aspect_ratio",
      default: "pb-[100%]",
      label: "Aspect Ratio",
      options: [
        {
          value: "pb-[125%]",
          label: "Portrait Format",
        },
        {
          value: "pb-[100%]",
          label: "Square",
        },
        {
          value: "pb-[75%]",
          label: "4/3 Landscape",
        },
      ],
    },
    {
      type: "radio",
      id: "image__order",
      label: "Layout",
      default: "-order-1",
      options: [
        {
          value: "-order-1",
          label: "Image on the left",
        },
        {
          value: "order-2",
          label: "Image on the right",
        },
      ],
    },
    {
      type: "header",
      content: "Content",
    },
    {
      type: "text",
      id: "preheading",
      label: "Pre heading",
    },
    typeRange({ id: "preheading_font", label: "Pre heading style", default_font: 3 }),
    {
      type: "text",
      id: "title",
      label: "Title",
    },
    typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
    {
      type: "textarea",
      id: "subtitle",
      label: "Subtitle",
    },
    typeRange({ id: "subtitle_font", label: "Subtitle style", default_font: 2 }),
    {
      type: "richtext",
      id: "content",
      label: "Richtext",
    },
    ...buttons.primary,
    ...buttons.secondary,
    {
      type: "radio",
      id: "align__vertical",
      label: "Vertical Alignment",
      default: "justify-center",
      options: [
        {
          value: "justify-start",
          label: "Top",
        },
        {
          value: "justify-center",
          label: "Center",
        },
        {
          value: "justify-end",
          label: "Bottom",
        },
      ],
    },
    {
      type: "radio",
      id: "align__horizontal",
      label: "Horizontal Alignment",
      default: "items-center text-center",
      options: [
        {
          value: "items-start text-left",
          label: "Left",
        },
        {
          value: "items-center text-center",
          label: "Center",
        },
        {
          value: "items-end text-right",
          label: "Right",
        },
      ],
    },
    {
      type: "header",
      content: "Layout",
    },

    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  presets: [
    {
      name: "Image with text",
    },
  ],
};
