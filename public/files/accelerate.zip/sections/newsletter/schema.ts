import { contentBlocks } from "globals/settings/content-blocks";
import { maxWidth } from "globals/settings/max-width";
import { sectionGlobals } from "globals/settings/section-globals";
import { NewsletterSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const newsletter: ShopifySection<NewsletterSection> = {
  name: "Email signup",
  generate_block_files: ["email"],
  settings: [
    {
      type: "header",
      content: "Image",
    },
    {
      type: "image_picker",
      id: "image",
      label: "Image",
    },
    {
      type: "color_background",
      id: "image__overlay",
      label: "Overlay",
      default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "header",
      content: "Layout",
    },
    maxWidth,
    {
      type: "radio",
      id: "align__vertical",
      label: "Vertical Alignment",
      default: "justify-center",
      options: [
        {
          value: "justify-start",
          label: "Top",
        },
        {
          value: "justify-center",
          label: "Center",
        },
        {
          value: "justify-end",
          label: "Bottom",
        },
      ],
    },
    {
      type: "radio",
      id: "align__horizontal",
      label: "Horizontal Alignment",
      default: "items-center text-center",
      options: [
        {
          value: "items-start text-left",
          label: "Left",
        },
        {
          value: "items-center text-center",
          label: "Center",
        },
        {
          value: "items-end text-right",
          label: "Right",
        },
      ],
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "email",
      name: "Signup Form",
      settings: [
        {
          type: "text",
          id: "placeholder_text",
          label: "Placeholder",
          default: "Enter your email",
        },
        {
          type: "text",
          id: "button_text",
          label: "Button Text",
          default: "Sign Up",
        },
        {
          type: "header",
          content: "Settings",
        },
        {
          type: "text",
          id: "tag",
          label: "Tag",
          info: "Assign a tag to subscribers using this Signup Form",
        },
        {
          type: "header" as const,
          content: "Layout",
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
      ],
    },
    contentBlocks.text,
    contentBlocks.image,
    contentBlocks.accentLine,
    contentBlocks.buttonGroup,
  ],
  presets: [
    {
      name: "Email signup",
    },
  ],
};
