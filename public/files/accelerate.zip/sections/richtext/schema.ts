import { contentBlocks } from "globals/settings/content-blocks";
import { maxWidth } from "globals/settings/max-width";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { RichtextSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const richtext: ShopifySection<RichtextSection> = {
  name: "Richtext",
  settings: [
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "radio",
      id: "align__horizontal",
      label: "Horizontal Alignment",
      default: "items-center text-center",
      options: [
        {
          value: "items-start text-left",
          label: "Left",
        },
        {
          value: "items-center text-center",
          label: "Center",
        },
        {
          value: "items-end text-right",
          label: "Right",
        },
      ],
    },
    maxWidth,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    contentBlocks.text,
    contentBlocks.image,
    contentBlocks.accentLine,
    contentBlocks.buttonGroup,
  ],
  presets: [
    {
      name: "Richtext",
    },
  ],
};
