import { sectionGlobals } from "globals/settings/section-globals";
import { iconList } from "globals/settings/icon-list";
import { FeaturesSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const features: ShopifySection<FeaturesSection> = {
  name: "Features",
  settings: [
    {
      type: "text",
      id: "preheading",
      label: "Pre Heading",
    },
    {
      type: "text",
      id: "title",
      label: "Title",
    },
    {
      type: "richtext",
      id: "description",
      label: "Description",
    },
    {
      type: "select",
      id: "layout",
      label: "Layout",
      default: "icon-flat",
      options: [
        {
          value: "icon-minimal",
          label: "Icon Minimal",
        },
        {
          value: "icon-flat",
          label: "Icon Flat",
        },
        {
          value: "icon-cards",
          label: "Icon Cards",
        },
        {
          value: "image-flat",
          label: "Image Flat",
        },
        {
          value: "image-column",
          label: "Image Column",
        },
        {
          value: "story",
          label: "Story",
        },
      ],
    },
    sectionGlobals.colorScheme,
  ],
  max_blocks: 8,
  blocks: [
    {
      type: "feature",
      name: "Feature",
      settings: [
        iconList,
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        {
          type: "richtext",
          id: "content",
          label: "Content",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
        {
          type: "textarea",
          id: "svg",
          label: "Svg",
        },
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
      ],
    },
  ],
  presets: [
    {
      name: "Features",
    },
  ],
};
