import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { MainCartSection } from "types/sections";

export const mainCart: ShopifySection<MainCartSection> = {
  name: "Main cart",
  settings: [sectionGlobals.topPadding, sectionGlobals.bottomPadding, sectionGlobals.colorScheme],
  blocks: [
    {
      type: "empty",
      name: "Empty Cart Screen",
      limit: 1,
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "preheading",
          label: "Pre heading",
        },
        {
          type: "text",
          id: "no_display_title",
          label: "Title",
        },
        {
          type: "textarea",
          id: "subtitle",
          label: "Subtitle",
        },
        {
          type: "richtext",
          id: "content",
          label: "Content",
        },
        {
          type: "text",
          id: "button_primary__text",
          label: "Primary Button",
        },
        {
          type: "url",
          id: "button_primary__url",
          label: "Primary Button Link",
        },
        {
          type: "text",
          id: "button_secondary__text",
          label: "Secondary Button",
        },
        {
          type: "url",
          id: "button_secondary__url",
          label: "Secondary Button Link",
        },
        {
          type: "header",
          content: "Layout",
        },
        {
          type: "range",
          id: "min_height",
          label: "Min Height",
          default: 320,
          min: 240,
          max: 640,
          step: 20,
          unit: "px",
        },
        {
          type: "radio",
          id: "align__vertical",
          label: "Vertical Alignment",
          default: "justify-center",
          options: [
            {
              value: "justify-start",
              label: "Top",
            },
            {
              value: "justify-center",
              label: "Center",
            },
            {
              value: "justify-end",
              label: "Bottom",
            },
          ],
        },
        {
          type: "radio",
          id: "align__horizontal",
          label: "Horizontal Alignment",
          default: "items-center text-center",
          options: [
            {
              value: "items-start text-left",
              label: "Left",
            },
            {
              value: "items-center text-center",
              label: "Center",
            },
            {
              value: "items-end text-right",
              label: "Right",
            },
          ],
        },
        sectionGlobals.sectionLayout,
        sectionGlobals.topPadding,
        sectionGlobals.bottomPadding,
        sectionGlobals.colorScheme,
      ],
    },
  ],
};
