import { sectionGlobals } from "globals/settings/section-globals";
import { ImageBannerSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const imageBanner: ShopifySection<ImageBannerSection> = {
  name: "Image banner",
  settings: [
    {
      type: "header",
      content: "Image",
    },
    {
      type: "image_picker",
      id: "image",
      label: "Image",
    },
    {
      type: "color_background",
      id: "image__overlay",
      label: "Overlay",
      default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "radio",
      id: "align__vertical",
      label: "Vertical Alignment",
      default: "justify-center",
      options: [
        {
          value: "justify-start",
          label: "Top",
        },
        {
          value: "justify-center",
          label: "Center",
        },
        {
          value: "justify-end",
          label: "Bottom",
        },
      ],
    },
    {
      type: "radio",
      id: "align__horizontal",
      label: "Horizontal Alignment",
      default: "items-center text-center",
      options: [
        {
          value: "items-start text-left",
          label: "Left",
        },
        {
          value: "items-center text-center",
          label: "Center",
        },
        {
          value: "items-end text-right",
          label: "Right",
        },
      ],
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "text",
      name: "Text",
      settings: [
        {
          type: "richtext",
          id: "title",
          label: "Content",
        },
        {
          type: "radio",
          id: "style",
          label: "Heading Style",
          default: "h2",
          options: [
            {
              value: "h1",
              label: "h1",
            },
            {
              value: "h2",
              label: "h2",
            },
            {
              value: "h3",
              label: "h3",
            },
            {
              value: "h4",
              label: "h4",
            },
            {
              value: "preheading",
              label: "pre-header",
            },
            {
              value: "richtext",
              label: "richtext",
            },
          ],
        },
      ],
    },
    {
      type: "image",
      name: "Inline Image",
      settings: [
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "range",
          id: "height",
          label: "Height",
          default: 80,
          min: 20,
          max: 200,
          step: 5,
          unit: "px",
        },
      ],
    },
    {
      type: "buttons",
      name: "Buttons",
      settings: [
        {
          type: "header",
          content: "Primary Button",
        },
        {
          type: "text",
          id: "button_primary__text",
          label: "Text",
        },
        {
          type: "url",
          id: "button_primary__url",
          label: "Url",
        },
        {
          type: "radio",
          id: "button_primary__style",
          label: "Style",
          default: "button-primary",
          options: [
            {
              value: "button-primary",
              label: "Primary",
            },
            {
              value: "button-primary--outline",
              label: "Primary Outline",
            },
            {
              value: "button-secondary",
              label: "Secondary",
            },
            {
              value: "button-secondary--outline",
              label: "Secondary Outline",
            },
          ],
        },
        {
          type: "header",
          content: "Secondary Button",
        },
        {
          type: "text",
          id: "button_secondary__text",
          label: "Text",
        },
        {
          type: "url",
          id: "button_secondary__url",
          label: "Url",
        },
        {
          type: "radio",
          id: "button_secondary__style",
          label: "Style",
          default: "button-primary--outline",
          options: [
            {
              value: "button-primary",
              label: "Primary",
            },
            {
              value: "button-primary--outline",
              label: "Primary Outline",
            },
            {
              value: "button-secondary",
              label: "Secondary",
            },
            {
              value: "button-secondary--outline",
              label: "Secondary Outline",
            },
          ],
        },
      ],
    },
  ],
  presets: [
    {
      name: "Image banner",
    },
  ],
};
