import { useLineItems } from "globals/utils/global-stores";
import { JSONParse, shortUUID } from "globals/utils/utils";
import { FC, useEffect, useRef } from "react";
import { ReactProductState } from "sections/product/product";
import { _Product_liquid } from "types/shopify";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductSideEffects: FC<{ useProduct: UseBoundStore<StoreApi<ReactProductState>> }> = ({
  useProduct,
}) => {
  const { cartData } = useLineItems();
  const { updateProduct, selectedVariant, product } = useProduct();
  const productData = useRef<_Product_liquid>(
    JSONParse(document.querySelector(`[data-product-json]`).innerHTML)
  );

  useEffect(() => {
    const product = productData.current;

    if (!window.Shopify.designMode) {
      updateProduct({
        ...product,
        variants: product.variants.map((variant) => {
          const lineItemQuantity = cartData?.items?.reduce(
            (acc, lineItem) => {
              if (lineItem.variant_id === variant.id) {
                acc += lineItem.quantity;
              }
              return acc;
            },
            0
          );
          if (lineItemQuantity === 0) return variant;

          const inventory_quantity = variant.inventory_quantity - lineItemQuantity;
          return {
            ...variant,
            available:
              inventory_quantity > 0 ||
              variant.inventory_policy === "continue" ||
              variant.inventory_management !== "shopify",
            inventory_quantity,
          };
        }),
      });
    }
  }, [cartData?.items, updateProduct]);

  useEffect(() => {
    if (window.location.pathname.includes(`/products/${product?.handle ?? shortUUID()}`)) {
      window.history.replaceState(null, null, `?variant=${selectedVariant?.id}`);
    }
  }, [product?.handle, selectedVariant?.id]);

  return null;
};
