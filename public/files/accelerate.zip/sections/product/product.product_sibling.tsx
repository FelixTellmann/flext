import { useGlobalProducts } from "globals/utils/global-stores";
import { ChevronUpDownIcon } from "globals/utils/icons";
import { toKebabCase } from "globals/utils/utils";
import { FC, useEffect, useMemo } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksProduct_sibling } from "types/sections";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductSibling: FC<{
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
  settings: ProductBlocksProduct_sibling["settings"];
}> = ({ useProduct, settings }) => {
  const { preloadProduct, products, hydrated } = useGlobalProducts(
    ({ preloadProduct, products, hydrated }) => ({
      preloadProduct,
      products,
      hydrated,
    })
  );
  const { product, productSiblings, setSiblingProduct } = useProduct(
    ({ product, productSiblings, setSiblingProduct }) => ({
      product,
      productSiblings,
      setSiblingProduct,
    })
  );

  const siblingGroup = useMemo(() => {
    return productSiblings.find((group) => group.products.some((p) => p.id === product.id));
  }, [product.id, productSiblings]);

  useEffect(() => {
    if (hydrated && siblingGroup) {
      siblingGroup.products.forEach((p) => preloadProduct(p.id, `/products/${p.handle}`));
    }
  }, [hydrated, preloadProduct, siblingGroup]);

  if (!siblingGroup) {
    return <></>;
  }

  const options = siblingGroup.options.split(",").map((option) => option.trim());

  switch (settings.selector) {
    case "image":
      return (
        <div>
          <h3 className="text-sm font-semibold">{siblingGroup.title}:</h3>
          <div className="relative pt-6">
            <fieldset className="group grid grid-cols-[repeat(auto-fill,3.5rem)] gap-1">
              {siblingGroup.products.map((sibling, index) => {
                return (
                  <label className="cursor-pointer" key={sibling.id}>
                    <input
                      type="radio"
                      name="product-sibling-selector"
                      value={sibling.id}
                      checked={sibling.id === product.id}
                      className="peer absolute appearance-none outline-none hfa:outline-none"
                      onChange={() => {
                        const siblingProduct = products[`${sibling.id}`];

                        if (!siblingProduct) {
                          return null;
                        }
                        setSiblingProduct(siblingProduct);
                      }}
                    />
                    <picture
                      data-product-sibling-title={options[index]}
                      className="flex h-14 w-14 overflow-hidden rounded-theme-md border-2 border-transparent bg-theme-bg before:absolute peer-checked:border-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 hf:border-theme-text/60 peer-disabled:hf:opacity-70 b:pointer-events-none b:top-0 b:left-0 b:text-xs b:text-theme-text/80 b:opacity-0 b:content-[attr(data-product-sibling-title)] peer-checked:b:opacity-100 hf:b:!opacity-100 group-hfa:b:opacity-0 peer-hfwa:border-primary-outline"
                    >
                      <img
                        src={`${sibling.image}&width=60&height=60`}
                        alt={options[index]}
                        className="pointer-events-none h-full w-full object-cover object-center"
                      />
                    </picture>
                  </label>
                );
              })}
            </fieldset>
          </div>
        </div>
      );
    case "color":
      return (
        <div>
          <h3 className="text-sm font-semibold">{siblingGroup.title}:</h3>
          <fieldset className="group mt-2 flex flex-wrap gap-2">
            {siblingGroup.products.map((sibling, index) => {
              return (
                <label
                  key={options[index]}
                  className="cursor-pointer rounded-full border border-theme-text/50"
                  title={options[index]}
                >
                  <input
                    type="radio"
                    name="product-sibling-selector"
                    className="peer absolute appearance-none outline-none hfa:outline-none"
                    value={options[index]}
                    onChange={() => {
                      const siblingProduct = products[`${sibling.id}`];

                      if (!siblingProduct) {
                        return null;
                      }
                      setSiblingProduct(siblingProduct);
                    }}
                    checked={sibling.id === product.id}
                  />

                  <span
                    className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full ring-2 ring-transparent ring-offset-1 peer-checked:ring-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 svg:opacity-0 peer-checked:svg:opacity-100 hf:ring-primary-outline peer-disabled:hf:opacity-70"
                    style={{
                      background: `var(--color-swatch--${toKebabCase(options[index])}, ${
                        options[index]
                      })`,
                    }}
                  ></span>
                </label>
              );
            })}
          </fieldset>
        </div>
      );
    case "radio":
      return (
        <div>
          <h3 className="text-sm font-semibold">{siblingGroup.title}:</h3>
          <fieldset className="group mt-2 flex flex-wrap gap-2">
            {siblingGroup.products.map((sibling, index) => {
              return (
                <label
                  key={options[index]}
                  className="cursor-pointer select-none"
                  title={options[index]}
                >
                  <input
                    type="radio"
                    name="product-sibling-selector"
                    className="peer absolute appearance-none outline-none hfa:outline-none"
                    value={options[index]}
                    onChange={() => {
                      const siblingProduct = products[`${sibling.id}`];

                      if (!siblingProduct) {
                        return null;
                      }
                      setSiblingProduct(siblingProduct);
                    }}
                    checked={sibling.id === product.id}
                  />

                  <span className="block max-w-[200px] truncate whitespace-nowrap rounded-theme-md border-2 border-transparent bg-theme-text/10 px-2.5 py-1.5 text-xs peer-checked:border-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 hf:border-primary-outline peer-disabled:hf:opacity-70">
                    {options[index]}
                  </span>
                </label>
              );
            })}
          </fieldset>
        </div>
      );
    case "select":
      return (
        <label className="relative">
          <span className="text-sm font-semibold">{siblingGroup.title}:</span>
          <select
            className="input-primary relative isolate grid w-full appearance-none pr-6 accent-primary-bg"
            onChange={(e) => {
              const sibling = products[`${e.currentTarget.value}`];

              if (!sibling) {
                return null;
              }

              setSiblingProduct(sibling);
            }}
          >
            {siblingGroup.products.map((sibling, index) => {
              return (
                <option
                  key={options[index]}
                  value={sibling.id}
                  className="disabled:text-theme-text/50"
                  selected={sibling.id === product.id}
                >
                  {options[index]}
                </option>
              );
            })}
          </select>
          <ChevronUpDownIcon className="pointer-events-none absolute right-2 bottom-0 z-10 my-2.5 h-5 w-5 text-theme-text/70" />
        </label>
      );
  }
};
