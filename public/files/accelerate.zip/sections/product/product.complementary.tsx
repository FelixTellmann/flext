import clsx from "clsx";
import { useGlobalProducts } from "globals/utils/global-stores";
import { ScrollBar } from "globals/utils/scrollbar";
import { FC, useCallback, useEffect, useMemo } from "react";
import { useProductDrawer } from "sections/product-drawer/product-drawer";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksComplementary } from "types/sections";
import { _Product_liquid } from "types/shopify";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductComplementaryItems: FC<{
  settings: ProductBlocksComplementary["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const { product } = useProduct();
  const { preloadProduct, getProduct, hydrated } = useGlobalProducts(
    ({ preloadProduct, getProduct, hydrated }) => ({
      preloadProduct,
      getProduct,
      hydrated,
    })
  );
  const { updateDrawerProduct } = useProductDrawer((state) => ({
    updateDrawerProduct: state?.updateProduct,
  }));

  const products = useMemo(() => {
    return (
      [
        ...((product.metafields?.["shopify--discovery--product_recommendation"]
          ?.complementary_products ?? []) as _Product_liquid[]),
        ...settings.products,
      ]
        ?.filter((p) => p.id !== product.id)
        ?.slice(0, 5) ?? []
    );
  }, [product.id, product.metafields, settings.products]);

  const handleViewComplementaryProduct = useCallback(async (e, upsellProduct: _Product_liquid) => {
    if (updateDrawerProduct) {
      e.preventDefault();
      updateDrawerProduct(getProduct(upsellProduct.id));
      // document.dispatchEvent(new Event("product:open"));
      setTimeout(() => document.dispatchEvent(new Event("product:open")), 1);
    }
  }, [getProduct, updateDrawerProduct]);

  useEffect(() => {
    if (hydrated) {
      products.forEach((product) => {
        preloadProduct(product.id, `/products/${product.handle}`);
      });
    }
  }, [hydrated, preloadProduct, products]);

  return (
    <div className="pb-4">
      <h2 className="h4 text-lg font-bold">{settings.title}</h2>
      <main className="relative py-4">
        <div
          className="scrollbar-none -my-8 grid snap-x snap-mandatory scroll-pl-8 grid-flow-col-dense gap-6 overflow-x-auto scroll-smooth py-8 "
          style={{ gridAutoColumns: "170px" }}
        >
          {products.map((upsellProduct) => {
            return (
              <article
                key={upsellProduct.id}
                className="relative flex flex-col items-stretch space-y-1 "
              >
                <a
                  className="relative grid h-0 w-full pb-[100%] outline-none hf:outline-none"
                  href={`/products/${upsellProduct.handle}`}
                >
                  <div
                    className={clsx(
                      "absolute inset-0 h-full w-full overflow-hidden",
                      !upsellProduct.featured_image && "opacity-0"
                    )}
                    style={{ background: "transparent" }}
                  >
                    <img
                      src={`${upsellProduct.featured_image}?v=1667663357&width=200`}
                      alt={upsellProduct.title}
                      width="170"
                      height="334"
                      className="inset-0 h-full w-full object-cover "
                    />
                  </div>
                  {upsellProduct.images[1]
                    ? <div className="absolute inset-0 h-full w-full overflow-hidden opacity-0 transition-all duration-75 hf:opacity-100">
                        <img
                          src={`${upsellProduct.images[1]}?v=1667663357&width=200`}
                          alt={upsellProduct.title}
                          width="170"
                          height="334"
                          className="inset-0 h-full w-full object-cover "
                        />
                      </div>
                    : null}

                  {upsellProduct.variants.length > 1
                    ? <div className="pointer-events-none absolute left-1/2 bottom-6 -translate-x-1/2 text-center text-xs tracking-wide text-theme-bg drop-shadow ">
                        Available in {upsellProduct.variants.length} variations
                      </div>
                    : null}
                </a>

                <h1 className=" inline-flex pt-2 text-sm font-semibold leading-[1.2] tracking-tight tracking-tight">
                  <a
                    className="outline-none hf:underline hf:outline-none"
                    href={`/products/${upsellProduct.handle}`}
                  >
                    {upsellProduct.title}
                  </a>
                </h1>

                <div className="text-xl" data-card-price="">
                  <div className=" grid auto-cols-min grid-flow-col-dense items-baseline gap-2 whitespace-nowrap text-sm font-semibold">
                    {upsellProduct.price_varies &&
                    upsellProduct.compare_at_price_min < upsellProduct.price_min
                      ? <span className="text-xs font-normal">On Sale from:</span>
                      : upsellProduct.price_varies
                      ? <span className="text-xs font-normal">From:</span>
                      : null}
                    <span className="">{window.formatMoney(upsellProduct.price_min)}</span>
                    {upsellProduct.compare_at_price > upsellProduct.price
                      ? <span className="text-xs text-theme-text/50 line-through">
                          {window.formatMoney(upsellProduct.compare_at_price)}
                        </span>
                      : null}
                  </div>
                </div>

                <div className="mt-auto mt-2 flex w-full flex-1 flex-col justify-end self-end text-center">
                  <a
                    className="button-primary mt-2 w-full px-3 py-1 text-sm outline-none hf:outline-none"
                    href={`/products/${upsellProduct.handle}`}
                    onClick={(e) => handleViewComplementaryProduct(e, upsellProduct)}
                  >
                    {upsellProduct.available
                      ? <span className="whitespace-nowrap">View</span>
                      : <span className="">Sold Out</span>}
                  </a>
                </div>
              </article>
            );
          })}
          <ScrollBar />
        </div>
      </main>
    </div>
  );
};
