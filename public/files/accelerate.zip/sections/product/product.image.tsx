import clsx from "clsx";
import { FC } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksImage } from "types/sections";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductImage: FC<{
  settings: ProductBlocksImage["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const { product } = useProduct();

  return (
    <figure
      className={clsx(
        "relative grid h-0 w-full outline-none hf:outline-none",
        settings.image__ratio
      )}
    >
      <div
        className="absolute inset-0 h-full w-full overflow-hidden rounded-theme shadow-md"
        style={{ background: settings.image__background }}
      >
        {product.featured_media
          ? <img
              src={`${product.featured_media?.preview_image.src}&width=180`}
              alt={product.featured_media?.alt ?? product.title}
              className={clsx(
                "inset-0 h-full w-full object-cover",
                settings.image__drop_shadow && "drop-shadow-product"
              )}
            />
          : null}
      </div>
    </figure>
  );
};
