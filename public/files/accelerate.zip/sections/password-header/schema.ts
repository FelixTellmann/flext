import { logoStyle } from "globals/settings/logo";
import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { PasswordHeaderSection } from "types/sections";

export const passwordHeader: ShopifySection<PasswordHeaderSection> = {
  name: "Password header",
  settings: [
    sectionGlobals.colorScheme,
    logoStyle,
    {
      type: "range",
      id: "logo_height",
      label: "Logo height",
      default: 80,
      min: 0,
      max: 100,
      step: 5,
      unit: "%",
    },
    {
      type: "link_list",
      id: "menu",
      default: "main-menu",
      label: "Menu",
    },
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "checkbox",
      id: "center_logo",
      label: "Center logo with hamburger menu",
      default: false,
    },
    {
      type: "range",
      id: "height",
      label: "Height",
      default: 75,
      min: 40,
      max: 200,
      step: 5,
      unit: "px",
    },
  ],
};
