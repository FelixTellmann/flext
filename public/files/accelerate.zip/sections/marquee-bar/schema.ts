import { sectionGlobals } from "globals/settings/section-globals";
import { MarqueeBarSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const marqueeBar: ShopifySection<MarqueeBarSection> = {
  name: "Marquee bar",
  disabled_block_files: true,
  settings: [
    {
      type: "range",
      id: "height",
      label: "Height",
      default: 130,
      min: 30,
      max: 300,
      step: 10,
      unit: "px",
    },
    {
      type: "checkbox",
      id: "highlight",
      label: "Highlight on Hover",
    },
    {
      type: "checkbox",
      id: "auto_pause",
      label: "Pause on Hover",
    },
    {
      type: "range",
      id: "duration",
      label: "Rotation Duration",
      default: 30,
      min: 7,
      max: 60,
      step: 1,
      unit: "s",
    },
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "text",
      name: "Text",
      settings: [
        {
          type: "textarea",
          id: "text",
          label: "Text",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
      ],
    },
    {
      type: "image",
      name: "Image",
      settings: [
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
      ],
    },
    {
      type: "svg",
      name: "SVG",
      settings: [
        {
          type: "textarea",
          id: "svg",
          label: "SVG Content",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
      ],
    },
  ],

  presets: [
    {
      name: "Marquee bar",
    },
  ],
};
