import { sectionGlobals } from "globals/settings/section-globals";
import { MainSearchFiltersSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainSearchFilters: ShopifySection<MainSearchFiltersSection> = {
  name: "Search Filter & Sort Bar",
  class: "section",
  settings: [
    {
      type: "header",
      content: "Filtering and sorting",
    },
    {
      type: "checkbox",
      id: "filters__show",
      default: true,
      label: "Enable filtering",
      info: "Customize [filters](/admin/menus)",
    },
    {
      type: "select",
      id: "filters__type",
      default: "cards",
      options: [
        {
          value: "megamenu",
          label: "Megamenu",
        },
        {
          value: "cards",
          label: "Cards",
        } /*
        {
          value: "drawer",
          label: "Drawer",
        },*/,
      ],
      label: "Desktop filter layout",
      info: "Drawer is the default mobile layout.",
    },
    {
      type: "checkbox",
      id: "filters__count",
      label: "Show Filter Count",
    },
    {
      type: "header",
      content: "Sorting",
    },
    {
      type: "checkbox",
      id: "sort__show",
      default: true,
      label: "Enable sorting",
    },
    sectionGlobals.colorScheme,
  ],
};
