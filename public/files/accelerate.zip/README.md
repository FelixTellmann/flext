# s6 Stack Theme Development - (Internal Alpha Version)

Typesafe Shopify Theme development to help you build your next Shopify theme.

## Stack Components

### fx-style
A internally developed ESLint/Prettier configuration for Shopify liquid / Next.js development that gets executed on every save and auto-formats your code and type-checks liquid/js/ts/html/css files. No additional packages or configuration needed to lint your project.

### shopify-ftp-access / shopfiy-cli
The theme can be easily setup to utilize the `Shopify-cli` or `Shopify-ftp-access` to deploy your theme to your Shopify store and live preview your changes. `shopify-ftp-access` is also an internal developed dev tool that allows you to access your theme via your preferred ftp client.

### shopify-theme-dev
This npm package is at the core of the S6 stack and generates your sections in a complete Typesafe manner and produces the `section` file, `snippet` file and the Types for your settings that you can use in your liquid files. It also generates your language files, which really allows you to focus on your development, instead of searching for the right language key.

### ts-node / webpack / js-modules
All code for the theme is written in Typescript and we includes a special configuration to automatically compile your Typescript files to Javascript files and also allows you to import your Javascript files as modules. This allows you to use the latest Javascript features and also allows you to import your Javascript files as modules or easily bundle external libraries into your codebase.

### Tailwind CSS
The theme is built with Tailwind CSS and includes a custom configuration to allow you to use the latest Tailwind CSS features. The tailwind config is setup that you can easily pick colors via Shopify and still use Tailwind's opacity variations. The produced CSS is 100% flat and any overrides are done via css variables which means you will never encounter any specificity issues. The added bonus is Tailwinds tiny file size in comparison to traditional CSS.

### shopify-cms
An internally developed codegen package to create `headless` Shopify themes based on Next.js / React to use Shopifys Theme editor & content as a headless-cms.

### Why s6 stack ?
The stack is heavily inspired by the `t3` stack which was created by Theo Ping and is based on his first name T plus three letters, similar to i18n and a11y to abbreviate internationalization and accessibility.

`s6` stands for Shopify, s plus 6 letters and makes up the `6` above mentioned components.
