const webpack = require("webpack");
const path = require("path");
const resolve = require("path").resolve;
const CompressionPlugin = require("compression-webpack-plugin");

module.exports = (env, argv) => {
  return {
    name: "client",
    target: "web",
    context: `${__dirname}`,
    entry: {
      theme: ["./globals/theme.ts"],
      editor: ["./globals/editor.tsx"],
    },
    output: {
      publicPath: "",
      filename: "[name].js",
      path: resolve(__dirname, `theme/assets`),
    },
    resolve: {
      extensions: [".ts", ".tsx", "jsx", ".js"],
      alias: {
        react: "preact/compat",
        "react-dom": "preact/compat",
      },
      modules: [path.resolve("./"), path.resolve("./node_modules")],
    },
    mode: "production",
    plugins: [
      /*new CompressionPlugin({
        algorithm: "gzip",
      }),*/
      /*new BundleAnalyzerPlugin({
        generateStatsFile: true,
      }),*/
    ],
    module: {
      rules: [
        { test: /\.js$/, loader: "source-map-loader", enforce: "pre" },
        {
          test: /\.tsx?$/,
          loader: "ts-loader",
          exclude: /node_modules/,
          options: {
            configFile: "tsconfig.shopify.json",
          },
        },
        {
          test: /\.scss$/,
          use: [
            {
              loader: "style-loader",
            },
            {
              loader: "css-loader",
            },
            {
              loader: "sass-loader",
            },
          ],
          exclude: /node_modules/,
        },
        {
          test: /\.css$/,
          use: [
            {
              loader: "style-loader",
            },
            {
              loader: "css-loader",
            },
            {
              loader: "postcss-loader",
            },
          ],
          exclude: /node_modules/,
        },
      ],
    },
  };
};
